package net.mcreator.asurvivorslegacy.entity.renderer;

import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.math.vector.Vector3f;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.IRenderTypeBuffer;

import net.mcreator.asurvivorslegacy.item.SlashItem;

import com.mojang.blaze3d.vertex.IVertexBuilder;
import com.mojang.blaze3d.matrix.MatrixStack;

@OnlyIn(Dist.CLIENT)
public class SlashRenderer {
	public static class ModelRegisterHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public void registerModels(ModelRegistryEvent event) {
			RenderingRegistry.registerEntityRenderingHandler(SlashItem.arrow, renderManager -> new CustomRender(renderManager));
		}
	}

	@OnlyIn(Dist.CLIENT)
	public static class CustomRender extends EntityRenderer<SlashItem.ArrowCustomEntity> {
		private static final ResourceLocation texture = new ResourceLocation("a_survivors_legacy:textures/slash.png");
		public CustomRender(EntityRendererManager renderManager) {
			super(renderManager);
		}

		@Override
		public void render(SlashItem.ArrowCustomEntity entityIn, float entityYaw, float partialTicks, MatrixStack matrixStackIn,
				IRenderTypeBuffer bufferIn, int packedLightIn) {
			IVertexBuilder vb = bufferIn.getBuffer(RenderType.getEntityCutout(this.getEntityTexture(entityIn)));
			matrixStackIn.push();
			matrixStackIn.rotate(Vector3f.YP.rotationDegrees(MathHelper.lerp(partialTicks, entityIn.prevRotationYaw, entityIn.rotationYaw) - 90));
			matrixStackIn.rotate(Vector3f.ZP.rotationDegrees(90 + MathHelper.lerp(partialTicks, entityIn.prevRotationPitch, entityIn.rotationPitch)));
			EntityModel model = new Modelslash();
			model.render(matrixStackIn, vb, packedLightIn, OverlayTexture.NO_OVERLAY, 1, 1, 1, 0.0625f);
			matrixStackIn.pop();
			super.render(entityIn, entityYaw, partialTicks, matrixStackIn, bufferIn, packedLightIn);
		}

		@Override
		public ResourceLocation getEntityTexture(SlashItem.ArrowCustomEntity entity) {
			return texture;
		}
	}

	// Made with Blockbench 3.9.2
	// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
	// Paste this class into your mod and generate all required imports
	public static class Modelslash extends EntityModel<Entity> {
		private final ModelRenderer bone;
		private final ModelRenderer bone2;
		private final ModelRenderer bone3;
		private final ModelRenderer bone4;
		private final ModelRenderer bone5;
		private final ModelRenderer bone6;
		private final ModelRenderer bone7;
		private final ModelRenderer bone8;
		public Modelslash() {
			textureWidth = 16;
			textureHeight = 16;
			bone = new ModelRenderer(this);
			bone.setRotationPoint(0.0F, 24.0F, 1.5F);
			bone.setTextureOffset(0, 0).addBox(1.0F, -1.0F, -2.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone.setTextureOffset(0, 2).addBox(-5.0F, -1.0F, -2.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone.setTextureOffset(0, 4).addBox(-2.0F, -1.0F, -3.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone2 = new ModelRenderer(this);
			bone2.setRotationPoint(0.0F, -0.5F, -1.8333F);
			bone.addChild(bone2);
			setRotationAngle(bone2, 0.0F, 0.0F, 1.5708F);
			bone2.setTextureOffset(0, 0).addBox(1.0F, -0.5F, -0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone2.setTextureOffset(0, 2).addBox(-5.0F, -0.5F, -0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone2.setTextureOffset(0, 4).addBox(-2.0F, -0.5F, -1.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone3 = new ModelRenderer(this);
			bone3.setRotationPoint(0.0F, -0.5F, -1.1667F);
			bone.addChild(bone3);
			setRotationAngle(bone3, 0.0F, 0.0F, 1.5708F);
			bone3.setTextureOffset(0, 0).addBox(1.0F, -0.5F, -0.8333F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone3.setTextureOffset(0, 2).addBox(-5.0F, -0.5F, -0.8333F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone3.setTextureOffset(0, 4).addBox(-2.0F, -0.5F, 0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone4 = new ModelRenderer(this);
			bone4.setRotationPoint(0.0F, 0.0F, -3.0F);
			bone.addChild(bone4);
			bone4.setTextureOffset(0, 0).addBox(1.0F, -1.0F, 1.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone4.setTextureOffset(0, 2).addBox(-5.0F, -1.0F, 1.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone4.setTextureOffset(0, 4).addBox(-2.0F, -1.0F, 2.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone5 = new ModelRenderer(this);
			bone5.setRotationPoint(0.0F, 24.0F, 0.0F);
			setRotationAngle(bone5, 0.0F, -1.5708F, 0.0F);
			bone5.setTextureOffset(0, 0).addBox(1.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone5.setTextureOffset(0, 2).addBox(-5.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone5.setTextureOffset(0, 4).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone6 = new ModelRenderer(this);
			bone6.setRotationPoint(0.0F, -0.5F, -0.3333F);
			bone5.addChild(bone6);
			setRotationAngle(bone6, 0.0F, 0.0F, 1.5708F);
			bone6.setTextureOffset(0, 0).addBox(1.0F, -0.5F, -0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone6.setTextureOffset(0, 2).addBox(-5.0F, -0.5F, -0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone6.setTextureOffset(0, 4).addBox(-2.0F, -0.5F, -1.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone7 = new ModelRenderer(this);
			bone7.setRotationPoint(0.0F, -0.5F, 0.3333F);
			bone5.addChild(bone7);
			setRotationAngle(bone7, 0.0F, 0.0F, 1.5708F);
			bone7.setTextureOffset(0, 0).addBox(1.0F, -0.5F, -0.8333F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone7.setTextureOffset(0, 2).addBox(-5.0F, -0.5F, -0.8333F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone7.setTextureOffset(0, 4).addBox(-2.0F, -0.5F, 0.1667F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone8 = new ModelRenderer(this);
			bone8.setRotationPoint(0.0F, 0.0F, -1.5F);
			bone5.addChild(bone8);
			bone8.setTextureOffset(0, 0).addBox(1.0F, -1.0F, 1.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone8.setTextureOffset(0, 2).addBox(-5.0F, -1.0F, 1.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
			bone8.setTextureOffset(0, 4).addBox(-2.0F, -1.0F, 2.0F, 4.0F, 1.0F, 1.0F, 0.0F, false);
		}

		@Override
		public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue,
				float alpha) {
			bone.render(matrixStack, buffer, packedLight, packedOverlay);
			bone5.render(matrixStack, buffer, packedLight, packedOverlay);
		}

		public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
			modelRenderer.rotateAngleX = x;
			modelRenderer.rotateAngleY = y;
			modelRenderer.rotateAngleZ = z;
		}

		public void setRotationAngles(Entity e, float f, float f1, float f2, float f3, float f4) {
		}
	}
}
