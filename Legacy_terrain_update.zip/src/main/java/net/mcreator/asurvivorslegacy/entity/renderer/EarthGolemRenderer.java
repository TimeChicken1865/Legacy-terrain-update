package net.mcreator.asurvivorslegacy.entity.renderer;

import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.model.ModelRenderer;
import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.entity.MobRenderer;

import net.mcreator.asurvivorslegacy.entity.EarthGolemEntity;

import com.mojang.blaze3d.vertex.IVertexBuilder;
import com.mojang.blaze3d.matrix.MatrixStack;

@OnlyIn(Dist.CLIENT)
public class EarthGolemRenderer {
	public static class ModelRegisterHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public void registerModels(ModelRegistryEvent event) {
			RenderingRegistry.registerEntityRenderingHandler(EarthGolemEntity.entity, renderManager -> {
				return new MobRenderer(renderManager, new ModelEgolem(), 0.5f) {
					@Override
					public ResourceLocation getEntityTexture(Entity entity) {
						return new ResourceLocation("a_survivors_legacy:textures/egolem.png");
					}
				};
			});
		}
	}

	// Made with Blockbench 3.9.2
	// Exported for Minecraft version 1.15
	// Paste this class into your mod and generate all required imports
	public static class ModelEgolem extends EntityModel<Entity> {
		private final ModelRenderer rightleg;
		private final ModelRenderer leftleg_r6_r1;
		private final ModelRenderer leftleg_r5_r1;
		private final ModelRenderer leftleg;
		private final ModelRenderer leftleg_r5_r2;
		private final ModelRenderer leftleg_r4_r1;
		private final ModelRenderer body;
		private final ModelRenderer cube_r1;
		private final ModelRenderer cube_r7_r1;
		private final ModelRenderer cube_r6_r1;
		private final ModelRenderer cube_r5_r1;
		private final ModelRenderer cube_r4_r1;
		private final ModelRenderer cube_r3_r1;
		private final ModelRenderer cube_r3_r2;
		private final ModelRenderer cube_r2_r1;
		private final ModelRenderer cube_r2_r2;
		private final ModelRenderer spines;
		private final ModelRenderer cube_r3_r3;
		private final ModelRenderer spines2;
		private final ModelRenderer cube_r4_r2;
		private final ModelRenderer spines4;
		private final ModelRenderer cube_r5_r2;
		private final ModelRenderer spines5;
		private final ModelRenderer cube_r6_r2;
		private final ModelRenderer spines3;
		private final ModelRenderer cube_r6_r3;
		private final ModelRenderer head;
		private final ModelRenderer leftarm;
		private final ModelRenderer leftleg_r6_r2;
		private final ModelRenderer leftleg_r5_r3;
		private final ModelRenderer rightarm;
		private final ModelRenderer leftleg_r9_r1;
		private final ModelRenderer leftleg_r7_r1;
		private final ModelRenderer leftleg_r6_r3;
		public ModelEgolem() {
			textureWidth = 256;
			textureHeight = 256;
			rightleg = new ModelRenderer(this);
			rightleg.setRotationPoint(0.0F, 24.0F, 0.0F);
			leftleg_r6_r1 = new ModelRenderer(this);
			leftleg_r6_r1.setRotationPoint(-19.3335F, -11.0049F, 2.3785F);
			rightleg.addChild(leftleg_r6_r1);
			setRotationAngle(leftleg_r6_r1, 1.4835F, -0.0873F, 0.3054F);
			leftleg_r6_r1.setTextureOffset(0, 87).addBox(-6.5F, -7.0F, -10.0F, 13.0F, 14.0F, 20.0F, 0.0F, false);
			leftleg_r5_r1 = new ModelRenderer(this);
			leftleg_r5_r1.setRotationPoint(-13.104F, -16.846F, 8.862F);
			rightleg.addChild(leftleg_r5_r1);
			setRotationAngle(leftleg_r5_r1, 0.3491F, 0.5236F, 0.3054F);
			leftleg_r5_r1.setTextureOffset(134, 0).addBox(-5.0F, -6.0F, -9.5F, 10.0F, 12.0F, 19.0F, 0.0F, false);
			leftleg = new ModelRenderer(this);
			leftleg.setRotationPoint(8.856F, 2.6909F, -2.8853F);
			leftleg_r5_r2 = new ModelRenderer(this);
			leftleg_r5_r2.setRotationPoint(7.5537F, 5.5725F, 6.8645F);
			leftleg.addChild(leftleg_r5_r2);
			setRotationAngle(leftleg_r5_r2, 1.4835F, 0.0873F, -0.3054F);
			leftleg_r5_r2.setTextureOffset(46, 107).addBox(-5.0F, -8.0F, -15.5F, 13.0F, 14.0F, 20.0F, 0.0F, false);
			leftleg_r4_r1 = new ModelRenderer(this);
			leftleg_r4_r1.setRotationPoint(4.248F, 4.4631F, 11.7473F);
			leftleg.addChild(leftleg_r4_r1);
			setRotationAngle(leftleg_r4_r1, 0.3491F, -0.5236F, -0.3054F);
			leftleg_r4_r1.setTextureOffset(43, 141).addBox(-5.0F, -6.0F, -9.5F, 10.0F, 12.0F, 19.0F, 0.0F, false);
			body = new ModelRenderer(this);
			body.setRotationPoint(0.0F, -1.0F, 10.0F);
			setRotationAngle(body, -0.48F, 0.0F, 0.0F);
			cube_r1 = new ModelRenderer(this);
			cube_r1.setRotationPoint(0.0F, 1.5F, -9.5F);
			body.addChild(cube_r1);
			setRotationAngle(cube_r1, -0.3054F, 0.0F, 0.0F);
			cube_r1.setTextureOffset(64, 68).addBox(-10.172F, -11.3226F, -9.1305F, 20.0F, 21.0F, 18.0F, 0.0F, false);
			cube_r1.setTextureOffset(150, 157).addBox(-9.172F, -2.3226F, -19.1305F, 18.0F, 12.0F, 11.0F, 0.0F, false);
			cube_r1.setTextureOffset(74, 29).addBox(-11.172F, -12.3226F, 8.8695F, 22.0F, 9.0F, 16.0F, 0.0F, false);
			cube_r7_r1 = new ModelRenderer(this);
			cube_r7_r1.setRotationPoint(4.4842F, -14.3414F, 44.8362F);
			cube_r1.addChild(cube_r7_r1);
			setRotationAngle(cube_r7_r1, 0.5236F, 0.8727F, 0.0F);
			cube_r7_r1.setTextureOffset(59, 54).addBox(-5.0F, -1.0F, -5.5F, 10.0F, 2.0F, 11.0F, 0.0F, false);
			cube_r6_r1 = new ModelRenderer(this);
			cube_r6_r1.setRotationPoint(-0.172F, -11.0914F, 41.2178F);
			cube_r1.addChild(cube_r6_r1);
			setRotationAngle(cube_r6_r1, 0.5236F, -0.8727F, 0.0F);
			cube_r6_r1.setTextureOffset(101, 54).addBox(-5.0F, -1.0F, 1.0F, 10.0F, 2.0F, 11.0F, 0.0F, false);
			cube_r5_r1 = new ModelRenderer(this);
			cube_r5_r1.setRotationPoint(-0.172F, -11.7745F, 41.4008F);
			cube_r1.addChild(cube_r5_r1);
			setRotationAngle(cube_r5_r1, 0.5236F, 0.0F, 0.0F);
			cube_r5_r1.setTextureOffset(162, 54).addBox(-5.0F, -2.5F, -4.5F, 10.0F, 6.0F, 8.0F, 0.0F, false);
			cube_r4_r1 = new ModelRenderer(this);
			cube_r4_r1.setRotationPoint(-0.172F, -9.287F, 35.3956F);
			cube_r1.addChild(cube_r4_r1);
			setRotationAngle(cube_r4_r1, 0.4363F, 0.0F, 0.0F);
			cube_r4_r1.setTextureOffset(92, 107).addBox(-7.0F, -3.5F, -3.0F, 14.0F, 9.0F, 6.0F, 0.0F, false);
			cube_r3_r1 = new ModelRenderer(this);
			cube_r3_r1.setRotationPoint(-0.172F, 3.1774F, 18.3695F);
			cube_r1.addChild(cube_r3_r1);
			setRotationAngle(cube_r3_r1, 0.3927F, 0.0F, 0.0F);
			cube_r3_r1.setTextureOffset(67, 8).addBox(-9.0F, -9.5F, 8.5F, 18.0F, 11.0F, 10.0F, 0.0F, false);
			cube_r3_r1.setTextureOffset(0, 8).addBox(-11.0F, -11.5F, -11.5F, 22.0F, 14.0F, 23.0F, 0.0F, false);
			cube_r3_r2 = new ModelRenderer(this);
			cube_r3_r2.setRotationPoint(-0.172F, 5.4661F, -24.1563F);
			cube_r1.addChild(cube_r3_r2);
			setRotationAngle(cube_r3_r2, 1.1781F, 0.0F, 0.0F);
			cube_r3_r2.setTextureOffset(150, 31).addBox(-8.0F, -1.5F, -1.5F, 16.0F, 8.0F, 15.0F, 0.0F, false);
			cube_r2_r1 = new ModelRenderer(this);
			cube_r2_r1.setRotationPoint(-0.172F, -1.3226F, -16.1305F);
			cube_r1.addChild(cube_r2_r1);
			setRotationAngle(cube_r2_r1, 0.6545F, 0.0F, 0.0F);
			cube_r2_r1.setTextureOffset(101, 142).addBox(-8.0F, -8.0F, 0.0F, 16.0F, 12.0F, 14.0F, 0.0F, false);
			cube_r2_r2 = new ModelRenderer(this);
			cube_r2_r2.setRotationPoint(-0.172F, -0.8226F, -0.1305F);
			cube_r1.addChild(cube_r2_r2);
			setRotationAngle(cube_r2_r2, -0.2618F, 0.0F, 0.0F);
			cube_r2_r2.setTextureOffset(0, 45).addBox(-9.0F, -12.5F, -14.0F, 18.0F, 18.0F, 23.0F, 0.0F, false);
			spines = new ModelRenderer(this);
			spines.setRotationPoint(-0.172F, -0.8226F, -0.1305F);
			cube_r1.addChild(spines);
			cube_r3_r3 = new ModelRenderer(this);
			cube_r3_r3.setRotationPoint(0.0F, 0.0F, 0.0F);
			spines.addChild(cube_r3_r3);
			setRotationAngle(cube_r3_r3, -0.2618F, 0.0F, 0.0F);
			cube_r3_r3.setTextureOffset(0, 8).addBox(0.0F, -23.5F, -8.0F, 1.0F, 11.0F, 7.0F, 0.0F, false);
			cube_r3_r3.setTextureOffset(59, 45).addBox(0.0F, -20.5F, -1.0F, 1.0F, 8.0F, 4.0F, 0.0F, false);
			cube_r3_r3.setTextureOffset(90, 54).addBox(0.0F, -20.5F, -11.0F, 1.0F, 8.0F, 3.0F, 0.0F, false);
			spines2 = new ModelRenderer(this);
			spines2.setRotationPoint(0.328F, -10.752F, -20.0204F);
			cube_r1.addChild(spines2);
			setRotationAngle(spines2, 0.9163F, 0.0F, 0.0F);
			cube_r4_r2 = new ModelRenderer(this);
			cube_r4_r2.setRotationPoint(-0.5F, 17.0F, 4.3333F);
			spines2.addChild(cube_r4_r2);
			setRotationAngle(cube_r4_r2, -0.2618F, 0.0F, 0.0F);
			cube_r4_r2.setTextureOffset(46, 86).addBox(0.0F, -20.5F, -7.0F, 1.0F, 8.0F, 6.0F, 0.0F, false);
			cube_r4_r2.setTextureOffset(98, 54).addBox(0.0F, -17.5F, -1.0F, 1.0F, 5.0F, 3.0F, 0.0F, false);
			cube_r4_r2.setTextureOffset(113, 8).addBox(0.0F, -17.5F, -10.0F, 1.0F, 5.0F, 3.0F, 0.0F, false);
			spines4 = new ModelRenderer(this);
			spines4.setRotationPoint(0.328F, -13.5794F, 12.5066F);
			cube_r1.addChild(spines4);
			setRotationAngle(spines4, 0.3054F, 0.0F, 0.0F);
			cube_r5_r2 = new ModelRenderer(this);
			cube_r5_r2.setRotationPoint(-0.5F, 17.0F, 4.3333F);
			spines4.addChild(cube_r5_r2);
			setRotationAngle(cube_r5_r2, -0.2618F, 0.0F, 0.0F);
			cube_r5_r2.setTextureOffset(8, 53).addBox(0.0F, -20.5F, -7.0F, 1.0F, 8.0F, 6.0F, 0.0F, false);
			cube_r5_r2.setTextureOffset(0, 59).addBox(0.0F, -17.5F, -1.0F, 1.0F, 5.0F, 3.0F, 0.0F, false);
			cube_r5_r2.setTextureOffset(59, 57).addBox(0.0F, -17.5F, -10.0F, 1.0F, 5.0F, 3.0F, 0.0F, false);
			spines5 = new ModelRenderer(this);
			spines5.setRotationPoint(0.328F, -10.7505F, 26.6486F);
			cube_r1.addChild(spines5);
			setRotationAngle(spines5, 0.3054F, 0.0F, 0.0F);
			cube_r6_r2 = new ModelRenderer(this);
			cube_r6_r2.setRotationPoint(-0.5F, 17.0F, 4.3333F);
			spines5.addChild(cube_r6_r2);
			setRotationAngle(cube_r6_r2, -0.2618F, 0.0F, 0.0F);
			cube_r6_r2.setTextureOffset(0, 45).addBox(0.0F, -20.5F, -7.0F, 1.0F, 8.0F, 6.0F, 0.0F, false);
			cube_r6_r2.setTextureOffset(13, 23).addBox(0.0F, -17.5F, -1.0F, 1.0F, 5.0F, 3.0F, 0.0F, false);
			cube_r6_r2.setTextureOffset(14, 45).addBox(0.0F, -17.5F, -10.0F, 1.0F, 5.0F, 3.0F, 0.0F, false);
			spines3 = new ModelRenderer(this);
			spines3.setRotationPoint(0.328F, 2.0615F, -23.9301F);
			cube_r1.addChild(spines3);
			setRotationAngle(spines3, 1.4835F, 0.0F, 0.0F);
			cube_r6_r3 = new ModelRenderer(this);
			cube_r6_r3.setRotationPoint(-0.5F, 15.5F, 4.0F);
			spines3.addChild(cube_r6_r3);
			setRotationAngle(cube_r6_r3, -0.2618F, 0.0F, 0.0F);
			cube_r6_r3.setTextureOffset(0, 86).addBox(0.0F, -21.9466F, -19.5661F, 1.0F, 8.0F, 6.0F, 0.0F, false);
			cube_r6_r3.setTextureOffset(0, 86).addBox(0.0F, -20.5F, -7.0F, 1.0F, 8.0F, 6.0F, 0.0F, false);
			cube_r6_r3.setTextureOffset(67, 8).addBox(0.0F, -17.5F, -1.0F, 1.0F, 5.0F, 3.0F, 0.0F, false);
			cube_r6_r3.setTextureOffset(11, 97).addBox(0.0F, -17.5F, -10.0F, 1.0F, 5.0F, 3.0F, 0.0F, false);
			head = new ModelRenderer(this);
			head.setRotationPoint(-0.0158F, -13.3414F, -26.1638F);
			setRotationAngle(head, 0.1745F, 0.0F, 0.0F);
			head.setTextureOffset(154, 112).addBox(-5.5F, -1.5F, -7.5F, 11.0F, 6.0F, 14.0F, 0.0F, false);
			head.setTextureOffset(9, 11).addBox(-4.5F, -3.5F, -7.5F, 3.0F, 2.0F, 0.0F, 0.0F, false);
			head.setTextureOffset(9, 9).addBox(1.5F, -3.5F, -7.5F, 3.0F, 2.0F, 0.0F, 0.0F, false);
			head.setTextureOffset(0, 7).addBox(5.5F, -3.5F, -3.5F, 0.0F, 2.0F, 3.0F, 0.0F, false);
			head.setTextureOffset(0, 5).addBox(-5.5F, -3.5F, -3.5F, 0.0F, 2.0F, 3.0F, 0.0F, false);
			head.setTextureOffset(162, 132).addBox(-4.5F, -7.5F, -5.5F, 9.0F, 11.0F, 12.0F, 0.0F, false);
			leftarm = new ModelRenderer(this);
			leftarm.setRotationPoint(13.7568F, -12.2087F, -11.5794F);
			setRotationAngle(leftarm, 1.6144F, 0.0F, 0.0F);
			leftleg_r6_r2 = new ModelRenderer(this);
			leftleg_r6_r2.setRotationPoint(2.6528F, 0.291F, -17.4271F);
			leftarm.addChild(leftleg_r6_r2);
			setRotationAngle(leftleg_r6_r2, -1.4835F, 0.0873F, 0.3054F);
			leftleg_r6_r2.setTextureOffset(140, 84).addBox(-7.0F, -6.0F, -13.5F, 11.0F, 10.0F, 18.0F, 0.0F, false);
			leftleg_r5_r3 = new ModelRenderer(this);
			leftleg_r5_r3.setRotationPoint(-0.6528F, 1.4004F, -12.5443F);
			leftarm.addChild(leftleg_r5_r3);
			setRotationAngle(leftleg_r5_r3, -0.3491F, -0.5236F, 0.3054F);
			leftleg_r5_r3.setTextureOffset(122, 54).addBox(-5.0F, -6.0F, -6.5F, 9.0F, 8.0F, 22.0F, 0.0F, false);
			rightarm = new ModelRenderer(this);
			rightarm.setRotationPoint(-7.2432F, -13.2087F, -12.5794F);
			setRotationAngle(rightarm, 1.1781F, -0.0873F, 0.0436F);
			leftleg_r9_r1 = new ModelRenderer(this);
			leftleg_r9_r1.setRotationPoint(-5.5773F, -9.5378F, -16.6163F);
			rightarm.addChild(leftleg_r9_r1);
			setRotationAngle(leftleg_r9_r1, -1.4835F, 0.1309F, 0.1309F);
			leftleg_r9_r1.setTextureOffset(0, 155).addBox(-24.0F, -4.0F, -9.0F, 7.0F, 8.0F, 17.0F, 0.0F, false);
			leftleg_r9_r1.setTextureOffset(0, 0).addBox(-25.0F, -2.0F, -2.0F, 68.0F, 4.0F, 4.0F, 0.0F, false);
			leftleg_r7_r1 = new ModelRenderer(this);
			leftleg_r7_r1.setRotationPoint(-9.0496F, 2.616F, -17.3071F);
			rightarm.addChild(leftleg_r7_r1);
			setRotationAngle(leftleg_r7_r1, -1.4835F, -0.0873F, -0.3054F);
			leftleg_r7_r1.setTextureOffset(112, 112).addBox(-4.0F, -6.0F, -15.5F, 11.0F, 10.0F, 20.0F, 0.0F, false);
			leftleg_r6_r3 = new ModelRenderer(this);
			leftleg_r6_r3.setRotationPoint(-5.7439F, 3.7255F, -12.4243F);
			rightarm.addChild(leftleg_r6_r3);
			setRotationAngle(leftleg_r6_r3, -0.3491F, 0.5236F, -0.3054F);
			leftleg_r6_r3.setTextureOffset(0, 121).addBox(-4.0F, -6.0F, -6.5F, 9.0F, 8.0F, 22.0F, 0.0F, false);
		}

		@Override
		public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue,
				float alpha) {
			rightleg.render(matrixStack, buffer, packedLight, packedOverlay);
			leftleg.render(matrixStack, buffer, packedLight, packedOverlay);
			body.render(matrixStack, buffer, packedLight, packedOverlay);
			head.render(matrixStack, buffer, packedLight, packedOverlay);
			leftarm.render(matrixStack, buffer, packedLight, packedOverlay);
			rightarm.render(matrixStack, buffer, packedLight, packedOverlay);
		}

		public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
			modelRenderer.rotateAngleX = x;
			modelRenderer.rotateAngleY = y;
			modelRenderer.rotateAngleZ = z;
		}

		public void setRotationAngles(Entity e, float f, float f1, float f2, float f3, float f4) {
			this.rightleg.rotateAngleX = MathHelper.cos(f * 1.0F) * 1.0F * f1;
			this.rightarm.rotateAngleY = MathHelper.cos(f * 0.6662F) * f1;
			this.leftleg.rotateAngleX = MathHelper.cos(f * 1.0F) * -1.0F * f1;
			this.leftarm.rotateAngleY = MathHelper.cos(f * 0.6662F) * f1;
		}
	}
}
