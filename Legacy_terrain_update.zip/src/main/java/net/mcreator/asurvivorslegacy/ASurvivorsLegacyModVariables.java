package net.mcreator.asurvivorslegacy;

import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.storage.WorldSavedData;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.world.IServerWorld;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Direction;
import net.minecraft.network.PacketBuffer;
import net.minecraft.nbt.INBT;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;

import java.util.function.Supplier;

public class ASurvivorsLegacyModVariables {
	public ASurvivorsLegacyModVariables(ASurvivorsLegacyModElements elements) {
		elements.addNetworkMessage(WorldSavedDataSyncMessage.class, WorldSavedDataSyncMessage::buffer, WorldSavedDataSyncMessage::new,
				WorldSavedDataSyncMessage::handler);
		elements.addNetworkMessage(PlayerVariablesSyncMessage.class, PlayerVariablesSyncMessage::buffer, PlayerVariablesSyncMessage::new,
				PlayerVariablesSyncMessage::handler);
		FMLJavaModLoadingContext.get().getModEventBus().addListener(this::init);
	}

	private void init(FMLCommonSetupEvent event) {
		CapabilityManager.INSTANCE.register(PlayerVariables.class, new PlayerVariablesStorage(), PlayerVariables::new);
	}

	@SubscribeEvent
	public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		if (!event.getPlayer().world.isRemote()) {
			WorldSavedData mapdata = MapVariables.get(event.getPlayer().world);
			WorldSavedData worlddata = WorldVariables.get(event.getPlayer().world);
			if (mapdata != null)
				ASurvivorsLegacyMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) event.getPlayer()),
						new WorldSavedDataSyncMessage(0, mapdata));
			if (worlddata != null)
				ASurvivorsLegacyMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) event.getPlayer()),
						new WorldSavedDataSyncMessage(1, worlddata));
		}
	}

	@SubscribeEvent
	public void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
		if (!event.getPlayer().world.isRemote()) {
			WorldSavedData worlddata = WorldVariables.get(event.getPlayer().world);
			if (worlddata != null)
				ASurvivorsLegacyMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) event.getPlayer()),
						new WorldSavedDataSyncMessage(1, worlddata));
		}
	}
	public static class WorldVariables extends WorldSavedData {
		public static final String DATA_NAME = "a_survivors_legacy_worldvars";
		public double MobSpawnDifficulty = 1.0;
		public WorldVariables() {
			super(DATA_NAME);
		}

		public WorldVariables(String s) {
			super(s);
		}

		@Override
		public void read(CompoundNBT nbt) {
			MobSpawnDifficulty = nbt.getDouble("MobSpawnDifficulty");
		}

		@Override
		public CompoundNBT write(CompoundNBT nbt) {
			nbt.putDouble("MobSpawnDifficulty", MobSpawnDifficulty);
			return nbt;
		}

		public void syncData(IWorld world) {
			this.markDirty();
			if (world instanceof World && !world.isRemote())
				ASurvivorsLegacyMod.PACKET_HANDLER.send(PacketDistributor.DIMENSION.with(((World) world)::getDimensionKey),
						new WorldSavedDataSyncMessage(1, this));
		}
		static WorldVariables clientSide = new WorldVariables();
		public static WorldVariables get(IWorld world) {
			if (world instanceof ServerWorld) {
				return ((ServerWorld) world).getSavedData().getOrCreate(WorldVariables::new, DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class MapVariables extends WorldSavedData {
		public static final String DATA_NAME = "a_survivors_legacy_mapvars";
		public boolean a = false;
		public boolean b = false;
		public boolean c = false;
		public boolean sprint = false;
		public boolean e = false;
		public double spawn = 0.0;
		public String damageedit = "\"\"";
		public MapVariables() {
			super(DATA_NAME);
		}

		public MapVariables(String s) {
			super(s);
		}

		@Override
		public void read(CompoundNBT nbt) {
			a = nbt.getBoolean("a");
			b = nbt.getBoolean("b");
			c = nbt.getBoolean("c");
			sprint = nbt.getBoolean("sprint");
			e = nbt.getBoolean("e");
			spawn = nbt.getDouble("spawn");
			damageedit = nbt.getString("damageedit");
		}

		@Override
		public CompoundNBT write(CompoundNBT nbt) {
			nbt.putBoolean("a", a);
			nbt.putBoolean("b", b);
			nbt.putBoolean("c", c);
			nbt.putBoolean("sprint", sprint);
			nbt.putBoolean("e", e);
			nbt.putDouble("spawn", spawn);
			nbt.putString("damageedit", damageedit);
			return nbt;
		}

		public void syncData(IWorld world) {
			this.markDirty();
			if (world instanceof World && !world.isRemote())
				ASurvivorsLegacyMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), new WorldSavedDataSyncMessage(0, this));
		}
		static MapVariables clientSide = new MapVariables();
		public static MapVariables get(IWorld world) {
			if (world instanceof IServerWorld) {
				return ((IServerWorld) world).getWorld().getServer().getWorld(World.OVERWORLD).getSavedData().getOrCreate(MapVariables::new,
						DATA_NAME);
			} else {
				return clientSide;
			}
		}
	}

	public static class WorldSavedDataSyncMessage {
		public int type;
		public WorldSavedData data;
		public WorldSavedDataSyncMessage(PacketBuffer buffer) {
			this.type = buffer.readInt();
			this.data = this.type == 0 ? new MapVariables() : new WorldVariables();
			this.data.read(buffer.readCompoundTag());
		}

		public WorldSavedDataSyncMessage(int type, WorldSavedData data) {
			this.type = type;
			this.data = data;
		}

		public static void buffer(WorldSavedDataSyncMessage message, PacketBuffer buffer) {
			buffer.writeInt(message.type);
			buffer.writeCompoundTag(message.data.write(new CompoundNBT()));
		}

		public static void handler(WorldSavedDataSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					if (message.type == 0)
						MapVariables.clientSide = (MapVariables) message.data;
					else
						WorldVariables.clientSide = (WorldVariables) message.data;
				}
			});
			context.setPacketHandled(true);
		}
	}
	@CapabilityInject(PlayerVariables.class)
	public static Capability<PlayerVariables> PLAYER_VARIABLES_CAPABILITY = null;
	@SubscribeEvent
	public void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
		if (event.getObject() instanceof PlayerEntity && !(event.getObject() instanceof FakePlayer))
			event.addCapability(new ResourceLocation("a_survivors_legacy", "player_variables"), new PlayerVariablesProvider());
	}
	private static class PlayerVariablesProvider implements ICapabilitySerializable<INBT> {
		private final LazyOptional<PlayerVariables> instance = LazyOptional.of(PLAYER_VARIABLES_CAPABILITY::getDefaultInstance);
		@Override
		public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
			return cap == PLAYER_VARIABLES_CAPABILITY ? instance.cast() : LazyOptional.empty();
		}

		@Override
		public INBT serializeNBT() {
			return PLAYER_VARIABLES_CAPABILITY.getStorage().writeNBT(PLAYER_VARIABLES_CAPABILITY, this.instance.orElseThrow(RuntimeException::new),
					null);
		}

		@Override
		public void deserializeNBT(INBT nbt) {
			PLAYER_VARIABLES_CAPABILITY.getStorage().readNBT(PLAYER_VARIABLES_CAPABILITY, this.instance.orElseThrow(RuntimeException::new), null,
					nbt);
		}
	}

	private static class PlayerVariablesStorage implements Capability.IStorage<PlayerVariables> {
		@Override
		public INBT writeNBT(Capability<PlayerVariables> capability, PlayerVariables instance, Direction side) {
			CompoundNBT nbt = new CompoundNBT();
			nbt.putDouble("damageamount3", instance.damageamount3);
			nbt.putDouble("magic_power3", instance.magic_power3);
			nbt.putDouble("amountfired3", instance.amountfired3);
			nbt.putDouble("manaamount3", instance.manaamount3);
			nbt.putDouble("DefenseMultiplier", instance.DefenseMultiplier);
			nbt.putDouble("DefenseAbility1", instance.DefenseAbility1);
			nbt.putDouble("DefenseAbility2", instance.DefenseAbility2);
			nbt.putDouble("death", instance.death);
			nbt.putDouble("DefenseAbility3", instance.DefenseAbility3);
			nbt.putDouble("water_amount", instance.water_amount);
			nbt.putBoolean("DefenseCooldown1", instance.DefenseCooldown1);
			nbt.putBoolean("DefenseCooldown2", instance.DefenseCooldown2);
			nbt.putBoolean("DefenseCooldown3", instance.DefenseCooldown3);
			nbt.putBoolean("swordstory", instance.swordstory);
			nbt.putDouble("strength", instance.strength);
			nbt.putBoolean("slashatk", instance.slashatk);
			nbt.putBoolean("dashatk", instance.dashatk);
			nbt.putBoolean("longswing", instance.longswing);
			nbt.putDouble("atk1", instance.atk1);
			nbt.putDouble("atk2", instance.atk2);
			nbt.putDouble("atk3", instance.atk3);
			nbt.putBoolean("inhand", instance.inhand);
			nbt.putBoolean("lingswingfire", instance.lingswingfire);
			nbt.putBoolean("start", instance.start);
			nbt.putBoolean("cooldown1", instance.cooldown1);
			nbt.putBoolean("cooldown2", instance.cooldown2);
			nbt.putBoolean("cooldown3", instance.cooldown3);
			nbt.putBoolean("slashatkfire", instance.slashatkfire);
			nbt.putBoolean("strengthon", instance.strengthon);
			nbt.putBoolean("dashatkfire", instance.dashatkfire);
			nbt.putBoolean("swordininv", instance.swordininv);
			nbt.putDouble("Mana", instance.Mana);
			nbt.putDouble("MaxMana", instance.MaxMana);
			nbt.putBoolean("Mstarts", instance.Mstarts);
			nbt.putDouble("manamultiplier", instance.manamultiplier);
			nbt.putDouble("varz", instance.varz);
			nbt.putDouble("varx", instance.varx);
			nbt.putBoolean("transporting", instance.transporting);
			nbt.putDouble("magic1", instance.magic1);
			nbt.putDouble("equip", instance.equip);
			nbt.putDouble("magic2", instance.magic2);
			nbt.putDouble("magic3", instance.magic3);
			nbt.putDouble("equip2", instance.equip2);
			nbt.putDouble("equip3", instance.equip3);
			nbt.putDouble("manaamount", instance.manaamount);
			nbt.putDouble("amountfired", instance.amountfired);
			nbt.putDouble("damageamount", instance.damageamount);
			nbt.putDouble("magic_power", instance.magic_power);
			nbt.putDouble("damageamount2", instance.damageamount2);
			nbt.putDouble("magic_power2", instance.magic_power2);
			nbt.putDouble("amountfired2", instance.amountfired2);
			nbt.putDouble("DefenseEquip1", instance.DefenseEquip1);
			nbt.putDouble("DefenseEquip2", instance.DefenseEquip2);
			nbt.putDouble("DefenseEquip3", instance.DefenseEquip3);
			nbt.putBoolean("autosprint", instance.autosprint);
			return nbt;
		}

		@Override
		public void readNBT(Capability<PlayerVariables> capability, PlayerVariables instance, Direction side, INBT inbt) {
			CompoundNBT nbt = (CompoundNBT) inbt;
			instance.damageamount3 = nbt.getDouble("damageamount3");
			instance.magic_power3 = nbt.getDouble("magic_power3");
			instance.amountfired3 = nbt.getDouble("amountfired3");
			instance.manaamount3 = nbt.getDouble("manaamount3");
			instance.DefenseMultiplier = nbt.getDouble("DefenseMultiplier");
			instance.DefenseAbility1 = nbt.getDouble("DefenseAbility1");
			instance.DefenseAbility2 = nbt.getDouble("DefenseAbility2");
			instance.death = nbt.getDouble("death");
			instance.DefenseAbility3 = nbt.getDouble("DefenseAbility3");
			instance.water_amount = nbt.getDouble("water_amount");
			instance.DefenseCooldown1 = nbt.getBoolean("DefenseCooldown1");
			instance.DefenseCooldown2 = nbt.getBoolean("DefenseCooldown2");
			instance.DefenseCooldown3 = nbt.getBoolean("DefenseCooldown3");
			instance.swordstory = nbt.getBoolean("swordstory");
			instance.strength = nbt.getDouble("strength");
			instance.slashatk = nbt.getBoolean("slashatk");
			instance.dashatk = nbt.getBoolean("dashatk");
			instance.longswing = nbt.getBoolean("longswing");
			instance.atk1 = nbt.getDouble("atk1");
			instance.atk2 = nbt.getDouble("atk2");
			instance.atk3 = nbt.getDouble("atk3");
			instance.inhand = nbt.getBoolean("inhand");
			instance.lingswingfire = nbt.getBoolean("lingswingfire");
			instance.start = nbt.getBoolean("start");
			instance.cooldown1 = nbt.getBoolean("cooldown1");
			instance.cooldown2 = nbt.getBoolean("cooldown2");
			instance.cooldown3 = nbt.getBoolean("cooldown3");
			instance.slashatkfire = nbt.getBoolean("slashatkfire");
			instance.strengthon = nbt.getBoolean("strengthon");
			instance.dashatkfire = nbt.getBoolean("dashatkfire");
			instance.swordininv = nbt.getBoolean("swordininv");
			instance.Mana = nbt.getDouble("Mana");
			instance.MaxMana = nbt.getDouble("MaxMana");
			instance.Mstarts = nbt.getBoolean("Mstarts");
			instance.manamultiplier = nbt.getDouble("manamultiplier");
			instance.varz = nbt.getDouble("varz");
			instance.varx = nbt.getDouble("varx");
			instance.transporting = nbt.getBoolean("transporting");
			instance.magic1 = nbt.getDouble("magic1");
			instance.equip = nbt.getDouble("equip");
			instance.magic2 = nbt.getDouble("magic2");
			instance.magic3 = nbt.getDouble("magic3");
			instance.equip2 = nbt.getDouble("equip2");
			instance.equip3 = nbt.getDouble("equip3");
			instance.manaamount = nbt.getDouble("manaamount");
			instance.amountfired = nbt.getDouble("amountfired");
			instance.damageamount = nbt.getDouble("damageamount");
			instance.magic_power = nbt.getDouble("magic_power");
			instance.damageamount2 = nbt.getDouble("damageamount2");
			instance.magic_power2 = nbt.getDouble("magic_power2");
			instance.amountfired2 = nbt.getDouble("amountfired2");
			instance.DefenseEquip1 = nbt.getDouble("DefenseEquip1");
			instance.DefenseEquip2 = nbt.getDouble("DefenseEquip2");
			instance.DefenseEquip3 = nbt.getDouble("DefenseEquip3");
			instance.autosprint = nbt.getBoolean("autosprint");
		}
	}

	public static class PlayerVariables {
		public double damageamount3 = 0;
		public double magic_power3 = 0;
		public double amountfired3 = 0.0;
		public double manaamount3 = 0;
		public double DefenseMultiplier = 0;
		public double DefenseAbility1 = 0;
		public double DefenseAbility2 = 0;
		public double death = 0;
		public double DefenseAbility3 = 0;
		public double water_amount = 10.0;
		public boolean DefenseCooldown1 = false;
		public boolean DefenseCooldown2 = false;
		public boolean DefenseCooldown3 = false;
		public boolean swordstory = false;
		public double strength = 0;
		public boolean slashatk = false;
		public boolean dashatk = false;
		public boolean longswing = false;
		public double atk1 = 0;
		public double atk2 = 0;
		public double atk3 = 0;
		public boolean inhand = false;
		public boolean lingswingfire = false;
		public boolean start = false;
		public boolean cooldown1 = false;
		public boolean cooldown2 = false;
		public boolean cooldown3 = false;
		public boolean slashatkfire = false;
		public boolean strengthon = false;
		public boolean dashatkfire = false;
		public boolean swordininv = false;
		public double Mana = 100.0;
		public double MaxMana = 100.0;
		public boolean Mstarts = false;
		public double manamultiplier = 0;
		public double varz = 0;
		public double varx = 0;
		public boolean transporting = false;
		public double magic1 = 0;
		public double equip = 0;
		public double magic2 = 0;
		public double magic3 = 0;
		public double equip2 = 0;
		public double equip3 = 0;
		public double manaamount = 0;
		public double amountfired = 0;
		public double damageamount = 0;
		public double magic_power = 0;
		public double damageamount2 = 0;
		public double magic_power2 = 0;
		public double amountfired2 = 0;
		public double DefenseEquip1 = 0;
		public double DefenseEquip2 = 0;
		public double DefenseEquip3 = 0;
		public boolean autosprint = false;
		public void syncPlayerVariables(Entity entity) {
			if (entity instanceof ServerPlayerEntity)
				ASurvivorsLegacyMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) entity),
						new PlayerVariablesSyncMessage(this));
		}
	}
	@SubscribeEvent
	public void onPlayerLoggedInSyncPlayerVariables(PlayerEvent.PlayerLoggedInEvent event) {
		if (!event.getPlayer().world.isRemote())
			((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
					.syncPlayerVariables(event.getPlayer());
	}

	@SubscribeEvent
	public void onPlayerRespawnedSyncPlayerVariables(PlayerEvent.PlayerRespawnEvent event) {
		if (!event.getPlayer().world.isRemote())
			((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
					.syncPlayerVariables(event.getPlayer());
	}

	@SubscribeEvent
	public void onPlayerChangedDimensionSyncPlayerVariables(PlayerEvent.PlayerChangedDimensionEvent event) {
		if (!event.getPlayer().world.isRemote())
			((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
					.syncPlayerVariables(event.getPlayer());
	}

	@SubscribeEvent
	public void clonePlayer(PlayerEvent.Clone event) {
		PlayerVariables original = ((PlayerVariables) event.getOriginal().getCapability(PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new PlayerVariables()));
		PlayerVariables clone = ((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()));
		clone.damageamount3 = original.damageamount3;
		clone.magic_power3 = original.magic_power3;
		clone.amountfired3 = original.amountfired3;
		clone.manaamount3 = original.manaamount3;
		clone.DefenseMultiplier = original.DefenseMultiplier;
		clone.DefenseAbility1 = original.DefenseAbility1;
		clone.DefenseAbility2 = original.DefenseAbility2;
		clone.death = original.death;
		clone.DefenseAbility3 = original.DefenseAbility3;
		clone.DefenseCooldown1 = original.DefenseCooldown1;
		clone.DefenseCooldown2 = original.DefenseCooldown2;
		clone.DefenseCooldown3 = original.DefenseCooldown3;
		clone.swordstory = original.swordstory;
		clone.strength = original.strength;
		clone.slashatk = original.slashatk;
		clone.dashatk = original.dashatk;
		clone.longswing = original.longswing;
		clone.atk1 = original.atk1;
		clone.atk2 = original.atk2;
		clone.atk3 = original.atk3;
		clone.inhand = original.inhand;
		clone.lingswingfire = original.lingswingfire;
		clone.start = original.start;
		clone.cooldown1 = original.cooldown1;
		clone.cooldown2 = original.cooldown2;
		clone.cooldown3 = original.cooldown3;
		clone.slashatkfire = original.slashatkfire;
		clone.strengthon = original.strengthon;
		clone.dashatkfire = original.dashatkfire;
		clone.swordininv = original.swordininv;
		clone.Mana = original.Mana;
		clone.MaxMana = original.MaxMana;
		clone.Mstarts = original.Mstarts;
		clone.manamultiplier = original.manamultiplier;
		clone.varz = original.varz;
		clone.varx = original.varx;
		clone.transporting = original.transporting;
		clone.magic1 = original.magic1;
		clone.equip = original.equip;
		clone.magic2 = original.magic2;
		clone.magic3 = original.magic3;
		clone.equip2 = original.equip2;
		clone.equip3 = original.equip3;
		clone.manaamount = original.manaamount;
		clone.amountfired = original.amountfired;
		clone.damageamount = original.damageamount;
		clone.magic_power = original.magic_power;
		clone.damageamount2 = original.damageamount2;
		clone.magic_power2 = original.magic_power2;
		clone.amountfired2 = original.amountfired2;
		clone.DefenseEquip1 = original.DefenseEquip1;
		clone.DefenseEquip2 = original.DefenseEquip2;
		clone.DefenseEquip3 = original.DefenseEquip3;
		clone.autosprint = original.autosprint;
		if (!event.isWasDeath()) {
			clone.water_amount = original.water_amount;
		}
	}
	public static class PlayerVariablesSyncMessage {
		public PlayerVariables data;
		public PlayerVariablesSyncMessage(PacketBuffer buffer) {
			this.data = new PlayerVariables();
			new PlayerVariablesStorage().readNBT(null, this.data, null, buffer.readCompoundTag());
		}

		public PlayerVariablesSyncMessage(PlayerVariables data) {
			this.data = data;
		}

		public static void buffer(PlayerVariablesSyncMessage message, PacketBuffer buffer) {
			buffer.writeCompoundTag((CompoundNBT) new PlayerVariablesStorage().writeNBT(null, message.data, null));
		}

		public static void handler(PlayerVariablesSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					PlayerVariables variables = ((PlayerVariables) Minecraft.getInstance().player.getCapability(PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new PlayerVariables()));
					variables.damageamount3 = message.data.damageamount3;
					variables.magic_power3 = message.data.magic_power3;
					variables.amountfired3 = message.data.amountfired3;
					variables.manaamount3 = message.data.manaamount3;
					variables.DefenseMultiplier = message.data.DefenseMultiplier;
					variables.DefenseAbility1 = message.data.DefenseAbility1;
					variables.DefenseAbility2 = message.data.DefenseAbility2;
					variables.death = message.data.death;
					variables.DefenseAbility3 = message.data.DefenseAbility3;
					variables.water_amount = message.data.water_amount;
					variables.DefenseCooldown1 = message.data.DefenseCooldown1;
					variables.DefenseCooldown2 = message.data.DefenseCooldown2;
					variables.DefenseCooldown3 = message.data.DefenseCooldown3;
					variables.swordstory = message.data.swordstory;
					variables.strength = message.data.strength;
					variables.slashatk = message.data.slashatk;
					variables.dashatk = message.data.dashatk;
					variables.longswing = message.data.longswing;
					variables.atk1 = message.data.atk1;
					variables.atk2 = message.data.atk2;
					variables.atk3 = message.data.atk3;
					variables.inhand = message.data.inhand;
					variables.lingswingfire = message.data.lingswingfire;
					variables.start = message.data.start;
					variables.cooldown1 = message.data.cooldown1;
					variables.cooldown2 = message.data.cooldown2;
					variables.cooldown3 = message.data.cooldown3;
					variables.slashatkfire = message.data.slashatkfire;
					variables.strengthon = message.data.strengthon;
					variables.dashatkfire = message.data.dashatkfire;
					variables.swordininv = message.data.swordininv;
					variables.Mana = message.data.Mana;
					variables.MaxMana = message.data.MaxMana;
					variables.Mstarts = message.data.Mstarts;
					variables.manamultiplier = message.data.manamultiplier;
					variables.varz = message.data.varz;
					variables.varx = message.data.varx;
					variables.transporting = message.data.transporting;
					variables.magic1 = message.data.magic1;
					variables.equip = message.data.equip;
					variables.magic2 = message.data.magic2;
					variables.magic3 = message.data.magic3;
					variables.equip2 = message.data.equip2;
					variables.equip3 = message.data.equip3;
					variables.manaamount = message.data.manaamount;
					variables.amountfired = message.data.amountfired;
					variables.damageamount = message.data.damageamount;
					variables.magic_power = message.data.magic_power;
					variables.damageamount2 = message.data.damageamount2;
					variables.magic_power2 = message.data.magic_power2;
					variables.amountfired2 = message.data.amountfired2;
					variables.DefenseEquip1 = message.data.DefenseEquip1;
					variables.DefenseEquip2 = message.data.DefenseEquip2;
					variables.DefenseEquip3 = message.data.DefenseEquip3;
					variables.autosprint = message.data.autosprint;
				}
			});
			context.setPacketHandled(true);
		}
	}
}
