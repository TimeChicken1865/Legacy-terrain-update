package net.mcreator.asurvivorslegacy.procedures;

import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import net.minecraft.enchantment.Enchantments;

import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModVariables;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.Map;

public class ArcmoschestplateinuseBodyTickEventProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency entity for procedure ArcmoschestplateinuseBodyTickEvent!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency itemstack for procedure ArcmoschestplateinuseBodyTickEvent!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		((itemstack)).addEnchantment(Enchantments.PROTECTION,
				(int) ((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).DefenseMultiplier));
	}
}
