package net.mcreator.asurvivorslegacy.procedures;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.IWorld;
import net.minecraft.util.Hand;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.asurvivorslegacy.item.SlashItem;
import net.mcreator.asurvivorslegacy.item.Longswing2Item;
import net.mcreator.asurvivorslegacy.item.DashfireItem;
import net.mcreator.asurvivorslegacy.item.ArcmoschestplateinuseItem;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModVariables;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.Random;
import java.util.Map;

public class ArcmosToolInHandTickProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency entity for procedure ArcmosToolInHandTick!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency world for procedure ArcmosToolInHandTick!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		IWorld world = (IWorld) dependencies.get("world");
		if (entity instanceof LivingEntity) {
			if (entity instanceof PlayerEntity)
				((PlayerEntity) entity).inventory.armorInventory.set((int) 2, new ItemStack(ArcmoschestplateinuseItem.body));
			else
				((LivingEntity) entity).setItemStackToSlot(EquipmentSlotType.fromSlotTypeAndIndex(EquipmentSlotType.Group.ARMOR, (int) 2),
						new ItemStack(ArcmoschestplateinuseItem.body));
			if (entity instanceof ServerPlayerEntity)
				((ServerPlayerEntity) entity).inventory.markDirty();
		}
		if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).cooldown1) == (false))) {
			if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).dashatkfire) == (true))) {
				{
					boolean _setval = (boolean) (true);
					entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.cooldown1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private IWorld world;
					public void start(IWorld world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						if (entity instanceof LivingEntity)
							((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.SPEED, (int) 10, (int) 7, (false), (false)));
						if (entity instanceof LivingEntity)
							((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.RESISTANCE, (int) 50, (int) 7, (false), (false)));
						if (entity instanceof LivingEntity) {
							Entity _ent = entity;
							if (!_ent.world.isRemote()) {
								DashfireItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 0.5,
										(float) (((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 8),
										(int) 2);
							}
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private IWorld world;
							public void start(IWorld world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity)
									((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.SPEED, (int) 10, (int) 7, (false), (false)));
								if (entity instanceof LivingEntity)
									((LivingEntity) entity)
											.addPotionEffect(new EffectInstance(Effects.RESISTANCE, (int) 50, (int) 7, (false), (false)));
								if (entity instanceof LivingEntity) {
									Entity _ent = entity;
									if (!_ent.world.isRemote()) {
										DashfireItem
												.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 0.5,
														(float) (((entity
																.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 8),
														(int) 2);
									}
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private IWorld world;
									public void start(IWorld world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity)
											((LivingEntity) entity)
													.addPotionEffect(new EffectInstance(Effects.SPEED, (int) 10, (int) 7, (false), (false)));
										if (entity instanceof LivingEntity)
											((LivingEntity) entity)
													.addPotionEffect(new EffectInstance(Effects.RESISTANCE, (int) 50, (int) 7, (false), (false)));
										if (entity instanceof LivingEntity) {
											Entity _ent = entity;
											if (!_ent.world.isRemote()) {
												DashfireItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 0.5,
														(float) (((entity
																.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 8),
														(int) 2);
											}
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private IWorld world;
											public void start(IWorld world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity)
													((LivingEntity) entity)
															.addPotionEffect(new EffectInstance(Effects.SPEED, (int) 10, (int) 7, (false), (false)));
												if (entity instanceof LivingEntity)
													((LivingEntity) entity).addPotionEffect(
															new EffectInstance(Effects.RESISTANCE, (int) 50, (int) 7, (false), (false)));
												if (entity instanceof LivingEntity) {
													Entity _ent = entity;
													if (!_ent.world.isRemote()) {
														DashfireItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 0.5,
																(float) (((entity
																		.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																		.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 8),
																(int) 2);
													}
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private IWorld world;
													public void start(IWorld world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity)
															((LivingEntity) entity).addPotionEffect(
																	new EffectInstance(Effects.SPEED, (int) 10, (int) 7, (false), (false)));
														if (entity instanceof LivingEntity)
															((LivingEntity) entity).addPotionEffect(
																	new EffectInstance(Effects.RESISTANCE, (int) 50, (int) 7, (false), (false)));
														if (entity instanceof LivingEntity) {
															Entity _ent = entity;
															if (!_ent.world.isRemote()) {
																DashfireItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 0.5,
																		(float) (((entity.getCapability(
																				ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																				+ 8),
																		(int) 2);
															}
														}
														new Object() {
															private int ticks = 0;
															private float waitTicks;
															private IWorld world;
															public void start(IWorld world, int waitTicks) {
																this.waitTicks = waitTicks;
																MinecraftForge.EVENT_BUS.register(this);
																this.world = world;
															}

															@SubscribeEvent
															public void tick(TickEvent.ServerTickEvent event) {
																if (event.phase == TickEvent.Phase.END) {
																	this.ticks += 1;
																	if (this.ticks >= this.waitTicks)
																		run();
																}
															}

															private void run() {
																if (entity instanceof LivingEntity)
																	((LivingEntity) entity).addPotionEffect(
																			new EffectInstance(Effects.SPEED, (int) 10, (int) 7, (false), (false)));
																if (entity instanceof LivingEntity)
																	((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.RESISTANCE,
																			(int) 50, (int) 7, (false), (false)));
																if (entity instanceof LivingEntity) {
																	Entity _ent = entity;
																	if (!_ent.world.isRemote()) {
																		DashfireItem.shoot(_ent.world, (LivingEntity) entity, new Random(),
																				(float) 0.5,
																				(float) (((entity.getCapability(
																						ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																						null)
																						.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																						+ 8),
																				(int) 2);
																	}
																}
																new Object() {
																	private int ticks = 0;
																	private float waitTicks;
																	private IWorld world;
																	public void start(IWorld world, int waitTicks) {
																		this.waitTicks = waitTicks;
																		MinecraftForge.EVENT_BUS.register(this);
																		this.world = world;
																	}

																	@SubscribeEvent
																	public void tick(TickEvent.ServerTickEvent event) {
																		if (event.phase == TickEvent.Phase.END) {
																			this.ticks += 1;
																			if (this.ticks >= this.waitTicks)
																				run();
																		}
																	}

																	private void run() {
																		if (entity instanceof LivingEntity)
																			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.SPEED,
																					(int) 10, (int) 7, (false), (false)));
																		if (entity instanceof LivingEntity)
																			((LivingEntity) entity).addPotionEffect(new EffectInstance(
																					Effects.RESISTANCE, (int) 50, (int) 7, (false), (false)));
																		if (entity instanceof LivingEntity) {
																			Entity _ent = entity;
																			if (!_ent.world.isRemote()) {
																				DashfireItem.shoot(_ent.world, (LivingEntity) entity, new Random(),
																						(float) 0.5,
																						(float) (((entity.getCapability(
																								ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																								null)
																								.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																								+ 8),
																						(int) 2);
																			}
																		}
																		new Object() {
																			private int ticks = 0;
																			private float waitTicks;
																			private IWorld world;
																			public void start(IWorld world, int waitTicks) {
																				this.waitTicks = waitTicks;
																				MinecraftForge.EVENT_BUS.register(this);
																				this.world = world;
																			}

																			@SubscribeEvent
																			public void tick(TickEvent.ServerTickEvent event) {
																				if (event.phase == TickEvent.Phase.END) {
																					this.ticks += 1;
																					if (this.ticks >= this.waitTicks)
																						run();
																				}
																			}

																			private void run() {
																				if (entity instanceof LivingEntity)
																					((LivingEntity) entity).addPotionEffect(new EffectInstance(
																							Effects.SPEED, (int) 10, (int) 7, (false), (false)));
																				if (entity instanceof LivingEntity)
																					((LivingEntity) entity).addPotionEffect(new EffectInstance(
																							Effects.RESISTANCE, (int) 50, (int) 7, (false), (false)));
																				if (entity instanceof LivingEntity) {
																					Entity _ent = entity;
																					if (!_ent.world.isRemote()) {
																						DashfireItem.shoot(_ent.world, (LivingEntity) entity,
																								new Random(), (float) 0.5,
																								(float) (((entity.getCapability(
																										ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																										null)
																										.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																										+ 8),
																								(int) 2);
																					}
																				}
																				new Object() {
																					private int ticks = 0;
																					private float waitTicks;
																					private IWorld world;
																					public void start(IWorld world, int waitTicks) {
																						this.waitTicks = waitTicks;
																						MinecraftForge.EVENT_BUS.register(this);
																						this.world = world;
																					}

																					@SubscribeEvent
																					public void tick(TickEvent.ServerTickEvent event) {
																						if (event.phase == TickEvent.Phase.END) {
																							this.ticks += 1;
																							if (this.ticks >= this.waitTicks)
																								run();
																						}
																					}

																					private void run() {
																						if (entity instanceof LivingEntity)
																							((LivingEntity) entity)
																									.addPotionEffect(new EffectInstance(Effects.SPEED,
																											(int) 10, (int) 7, (false), (false)));
																						if (entity instanceof LivingEntity)
																							((LivingEntity) entity).addPotionEffect(
																									new EffectInstance(Effects.RESISTANCE, (int) 50,
																											(int) 7, (false), (false)));
																						if (entity instanceof LivingEntity) {
																							Entity _ent = entity;
																							if (!_ent.world.isRemote()) {
																								DashfireItem.shoot(_ent.world, (LivingEntity) entity,
																										new Random(), (float) 0.5,
																										(float) (((entity.getCapability(
																												ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																												null)
																												.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																												+ 8),
																										(int) 2);
																							}
																						}
																						new Object() {
																							private int ticks = 0;
																							private float waitTicks;
																							private IWorld world;
																							public void start(IWorld world, int waitTicks) {
																								this.waitTicks = waitTicks;
																								MinecraftForge.EVENT_BUS.register(this);
																								this.world = world;
																							}

																							@SubscribeEvent
																							public void tick(TickEvent.ServerTickEvent event) {
																								if (event.phase == TickEvent.Phase.END) {
																									this.ticks += 1;
																									if (this.ticks >= this.waitTicks)
																										run();
																								}
																							}

																							private void run() {
																								if (entity instanceof LivingEntity)
																									((LivingEntity) entity).addPotionEffect(
																											new EffectInstance(Effects.SPEED,
																													(int) 10, (int) 7, (false),
																													(false)));
																								if (entity instanceof LivingEntity)
																									((LivingEntity) entity).addPotionEffect(
																											new EffectInstance(Effects.RESISTANCE,
																													(int) 50, (int) 7, (false),
																													(false)));
																								if (entity instanceof LivingEntity) {
																									Entity _ent = entity;
																									if (!_ent.world.isRemote()) {
																										DashfireItem.shoot(_ent.world,
																												(LivingEntity) entity, new Random(),
																												(float) 0.5,
																												(float) (((entity.getCapability(
																														ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																														null)
																														.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																														+ 8),
																												(int) 2);
																									}
																								}
																								new Object() {
																									private int ticks = 0;
																									private float waitTicks;
																									private IWorld world;
																									public void start(IWorld world, int waitTicks) {
																										this.waitTicks = waitTicks;
																										MinecraftForge.EVENT_BUS.register(this);
																										this.world = world;
																									}

																									@SubscribeEvent
																									public void tick(
																											TickEvent.ServerTickEvent event) {
																										if (event.phase == TickEvent.Phase.END) {
																											this.ticks += 1;
																											if (this.ticks >= this.waitTicks)
																												run();
																										}
																									}

																									private void run() {
																										if (entity instanceof LivingEntity)
																											((LivingEntity) entity).addPotionEffect(
																													new EffectInstance(Effects.SPEED,
																															(int) 10, (int) 7,
																															(false), (false)));
																										if (entity instanceof LivingEntity)
																											((LivingEntity) entity).addPotionEffect(
																													new EffectInstance(
																															Effects.RESISTANCE,
																															(int) 50, (int) 7,
																															(false), (false)));
																										if (entity instanceof LivingEntity) {
																											Entity _ent = entity;
																											if (!_ent.world.isRemote()) {
																												DashfireItem.shoot(_ent.world,
																														(LivingEntity) entity,
																														new Random(), (float) 0.5,
																														(float) (((entity
																																.getCapability(
																																		ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																		null)
																																.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																+ 8),
																														(int) 2);
																											}
																										}
																										new Object() {
																											private int ticks = 0;
																											private float waitTicks;
																											private IWorld world;
																											public void start(IWorld world,
																													int waitTicks) {
																												this.waitTicks = waitTicks;
																												MinecraftForge.EVENT_BUS
																														.register(this);
																												this.world = world;
																											}

																											@SubscribeEvent
																											public void tick(
																													TickEvent.ServerTickEvent event) {
																												if (event.phase == TickEvent.Phase.END) {
																													this.ticks += 1;
																													if (this.ticks >= this.waitTicks)
																														run();
																												}
																											}

																											private void run() {
																												if (entity instanceof LivingEntity)
																													((LivingEntity) entity)
																															.addPotionEffect(
																																	new EffectInstance(
																																			Effects.SPEED,
																																			(int) 10,
																																			(int) 7,
																																			(false),
																																			(false)));
																												if (entity instanceof LivingEntity)
																													((LivingEntity) entity)
																															.addPotionEffect(
																																	new EffectInstance(
																																			Effects.RESISTANCE,
																																			(int) 50,
																																			(int) 7,
																																			(false),
																																			(false)));
																												if (entity instanceof LivingEntity) {
																													Entity _ent = entity;
																													if (!_ent.world.isRemote()) {
																														DashfireItem.shoot(_ent.world,
																																(LivingEntity) entity,
																																new Random(),
																																(float) 0.5,
																																(float) (((entity
																																		.getCapability(
																																				ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																				null)
																																		.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																		+ 8),
																																(int) 2);
																													}
																												}
																												new Object() {
																													private int ticks = 0;
																													private float waitTicks;
																													private IWorld world;
																													public void start(IWorld world,
																															int waitTicks) {
																														this.waitTicks = waitTicks;
																														MinecraftForge.EVENT_BUS
																																.register(this);
																														this.world = world;
																													}

																													@SubscribeEvent
																													public void tick(
																															TickEvent.ServerTickEvent event) {
																														if (event.phase == TickEvent.Phase.END) {
																															this.ticks += 1;
																															if (this.ticks >= this.waitTicks)
																																run();
																														}
																													}

																													private void run() {
																														if (entity instanceof LivingEntity)
																															((LivingEntity) entity)
																																	.addPotionEffect(
																																			new EffectInstance(
																																					Effects.SPEED,
																																					(int) 10,
																																					(int) 7,
																																					(false),
																																					(false)));
																														if (entity instanceof LivingEntity)
																															((LivingEntity) entity)
																																	.addPotionEffect(
																																			new EffectInstance(
																																					Effects.RESISTANCE,
																																					(int) 50,
																																					(int) 7,
																																					(false),
																																					(false)));
																														if (entity instanceof LivingEntity) {
																															Entity _ent = entity;
																															if (!_ent.world
																																	.isRemote()) {
																																DashfireItem.shoot(
																																		_ent.world,
																																		(LivingEntity) entity,
																																		new Random(),
																																		(float) 0.5,
																																		(float) (((entity
																																				.getCapability(
																																						ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																						null)
																																				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																				+ 8),
																																		(int) 2);
																															}
																														}
																														new Object() {
																															private int ticks = 0;
																															private float waitTicks;
																															private IWorld world;
																															public void start(
																																	IWorld world,
																																	int waitTicks) {
																																this.waitTicks = waitTicks;
																																MinecraftForge.EVENT_BUS
																																		.register(
																																				this);
																																this.world = world;
																															}

																															@SubscribeEvent
																															public void tick(
																																	TickEvent.ServerTickEvent event) {
																																if (event.phase == TickEvent.Phase.END) {
																																	this.ticks += 1;
																																	if (this.ticks >= this.waitTicks)
																																		run();
																																}
																															}

																															private void run() {
																																if (entity instanceof LivingEntity)
																																	((LivingEntity) entity)
																																			.addPotionEffect(
																																					new EffectInstance(
																																							Effects.SPEED,
																																							(int) 10,
																																							(int) 7,
																																							(false),
																																							(false)));
																																if (entity instanceof LivingEntity)
																																	((LivingEntity) entity)
																																			.addPotionEffect(
																																					new EffectInstance(
																																							Effects.RESISTANCE,
																																							(int) 50,
																																							(int) 7,
																																							(false),
																																							(false)));
																																if (entity instanceof LivingEntity) {
																																	Entity _ent = entity;
																																	if (!_ent.world
																																			.isRemote()) {
																																		DashfireItem
																																				.shoot(_ent.world,
																																						(LivingEntity) entity,
																																						new Random(),
																																						(float) 0.5,
																																						(float) (((entity
																																								.getCapability(
																																										ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																										null)
																																								.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																								+ 8),
																																						(int) 2);
																																	}
																																}
																																new Object() {
																																	private int ticks = 0;
																																	private float waitTicks;
																																	private IWorld world;
																																	public void start(
																																			IWorld world,
																																			int waitTicks) {
																																		this.waitTicks = waitTicks;
																																		MinecraftForge.EVENT_BUS
																																				.register(
																																						this);
																																		this.world = world;
																																	}

																																	@SubscribeEvent
																																	public void tick(
																																			TickEvent.ServerTickEvent event) {
																																		if (event.phase == TickEvent.Phase.END) {
																																			this.ticks += 1;
																																			if (this.ticks >= this.waitTicks)
																																				run();
																																		}
																																	}

																																	private void run() {
																																		if (entity instanceof LivingEntity)
																																			((LivingEntity) entity)
																																					.addPotionEffect(
																																							new EffectInstance(
																																									Effects.SPEED,
																																									(int) 10,
																																									(int) 7,
																																									(false),
																																									(false)));
																																		if (entity instanceof LivingEntity)
																																			((LivingEntity) entity)
																																					.addPotionEffect(
																																							new EffectInstance(
																																									Effects.RESISTANCE,
																																									(int) 50,
																																									(int) 7,
																																									(false),
																																									(false)));
																																		if (entity instanceof LivingEntity) {
																																			Entity _ent = entity;
																																			if (!_ent.world
																																					.isRemote()) {
																																				DashfireItem
																																						.shoot(_ent.world,
																																								(LivingEntity) entity,
																																								new Random(),
																																								(float) 0.5,
																																								(float) (((entity
																																										.getCapability(
																																												ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																												null)
																																										.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																										+ 8),
																																								(int) 2);
																																			}
																																		}
																																		new Object() {
																																			private int ticks = 0;
																																			private float waitTicks;
																																			private IWorld world;
																																			public void start(
																																					IWorld world,
																																					int waitTicks) {
																																				this.waitTicks = waitTicks;
																																				MinecraftForge.EVENT_BUS
																																						.register(
																																								this);
																																				this.world = world;
																																			}

																																			@SubscribeEvent
																																			public void tick(
																																					TickEvent.ServerTickEvent event) {
																																				if (event.phase == TickEvent.Phase.END) {
																																					this.ticks += 1;
																																					if (this.ticks >= this.waitTicks)
																																						run();
																																				}
																																			}

																																			private void run() {
																																				if (entity instanceof LivingEntity)
																																					((LivingEntity) entity)
																																							.addPotionEffect(
																																									new EffectInstance(
																																											Effects.SPEED,
																																											(int) 10,
																																											(int) 7,
																																											(false),
																																											(false)));
																																				if (entity instanceof LivingEntity)
																																					((LivingEntity) entity)
																																							.addPotionEffect(
																																									new EffectInstance(
																																											Effects.RESISTANCE,
																																											(int) 50,
																																											(int) 7,
																																											(false),
																																											(false)));
																																				if (entity instanceof LivingEntity) {
																																					Entity _ent = entity;
																																					if (!_ent.world
																																							.isRemote()) {
																																						DashfireItem
																																								.shoot(_ent.world,
																																										(LivingEntity) entity,
																																										new Random(),
																																										(float) 0.5,
																																										(float) (((entity
																																												.getCapability(
																																														ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																														null)
																																												.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																												+ 8),
																																										(int) 2);
																																					}
																																				}
																																				MinecraftForge.EVENT_BUS
																																						.unregister(
																																								this);
																																			}
																																		}.start(world,
																																				(int) 2);
																																		MinecraftForge.EVENT_BUS
																																				.unregister(
																																						this);
																																	}
																																}.start(world,
																																		(int) 2);
																																MinecraftForge.EVENT_BUS
																																		.unregister(
																																				this);
																															}
																														}.start(world, (int) 2);
																														MinecraftForge.EVENT_BUS
																																.unregister(this);
																													}
																												}.start(world, (int) 2);
																												MinecraftForge.EVENT_BUS
																														.unregister(this);
																											}
																										}.start(world, (int) 2);
																										MinecraftForge.EVENT_BUS.unregister(this);
																									}
																								}.start(world, (int) 2);
																								MinecraftForge.EVENT_BUS.unregister(this);
																							}
																						}.start(world, (int) 2);
																						MinecraftForge.EVENT_BUS.unregister(this);
																					}
																				}.start(world, (int) 2);
																				MinecraftForge.EVENT_BUS.unregister(this);
																			}
																		}.start(world, (int) 2);
																		MinecraftForge.EVENT_BUS.unregister(this);
																	}
																}.start(world, (int) 2);
																MinecraftForge.EVENT_BUS.unregister(this);
															}
														}.start(world, (int) 2);
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, (int) 2);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, (int) 2);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, (int) 2);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, (int) 2);
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, (int) 2);
				{
					boolean _setval = (boolean) (false);
					entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.dashatkfire = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private IWorld world;
					public void start(IWorld world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						{
							boolean _setval = (boolean) (false);
							entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.cooldown1 = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, (int) 300);
			}
		}
		if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).cooldown3) == (false))) {
			if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).lingswingfire) == (true))) {
				{
					boolean _setval = (boolean) (false);
					entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.lingswingfire = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					boolean _setval = (boolean) (true);
					entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.cooldown3 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				if (entity instanceof LivingEntity) {
					Entity _ent = entity;
					if (!_ent.world.isRemote()) {
						Longswing2Item.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 0.5,
								(float) (((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 7),
								(int) 2);
					}
				}
				if (entity instanceof LivingEntity) {
					((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
				}
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private IWorld world;
					public void start(IWorld world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						{
							boolean _setval = (boolean) (false);
							entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.cooldown3 = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, (int) 15);
			}
		}
		if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).cooldown2) == (false))) {
			if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).slashatkfire) == (true))) {
				{
					boolean _setval = (boolean) (true);
					entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.cooldown2 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				if (entity instanceof LivingEntity) {
					((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
				}
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private IWorld world;
					public void start(IWorld world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						if (entity instanceof LivingEntity) {
							Entity _ent = entity;
							if (!_ent.world.isRemote()) {
								SlashItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 2,
										(float) (((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
												.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 5),
										(int) 0.5);
							}
						}
						if (entity instanceof LivingEntity) {
							((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private IWorld world;
							public void start(IWorld world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity) {
									Entity _ent = entity;
									if (!_ent.world.isRemote()) {
										SlashItem
												.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 2,
														(float) (((entity
																.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 5),
														(int) 0.5);
									}
								}
								if (entity instanceof LivingEntity) {
									((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private IWorld world;
									public void start(IWorld world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity) {
											Entity _ent = entity;
											if (!_ent.world.isRemote()) {
												SlashItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 2,
														(float) (((entity
																.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 5),
														(int) 0.5);
											}
										}
										if (entity instanceof LivingEntity) {
											((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private IWorld world;
											public void start(IWorld world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity) {
													Entity _ent = entity;
													if (!_ent.world.isRemote()) {
														SlashItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 2,
																(float) (((entity
																		.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																		.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 5),
																(int) 0.5);
													}
												}
												if (entity instanceof LivingEntity) {
													((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private IWorld world;
													public void start(IWorld world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity) {
															Entity _ent = entity;
															if (!_ent.world.isRemote()) {
																SlashItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 2,
																		(float) (((entity.getCapability(
																				ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
																				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																				+ 5),
																		(int) 0.5);
															}
														}
														if (entity instanceof LivingEntity) {
															((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
														}
														new Object() {
															private int ticks = 0;
															private float waitTicks;
															private IWorld world;
															public void start(IWorld world, int waitTicks) {
																this.waitTicks = waitTicks;
																MinecraftForge.EVENT_BUS.register(this);
																this.world = world;
															}

															@SubscribeEvent
															public void tick(TickEvent.ServerTickEvent event) {
																if (event.phase == TickEvent.Phase.END) {
																	this.ticks += 1;
																	if (this.ticks >= this.waitTicks)
																		run();
																}
															}

															private void run() {
																if (entity instanceof LivingEntity) {
																	Entity _ent = entity;
																	if (!_ent.world.isRemote()) {
																		SlashItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 2,
																				(float) (((entity.getCapability(
																						ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																						null)
																						.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																						+ 5),
																				(int) 0.5);
																	}
																}
																if (entity instanceof LivingEntity) {
																	((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
																}
																new Object() {
																	private int ticks = 0;
																	private float waitTicks;
																	private IWorld world;
																	public void start(IWorld world, int waitTicks) {
																		this.waitTicks = waitTicks;
																		MinecraftForge.EVENT_BUS.register(this);
																		this.world = world;
																	}

																	@SubscribeEvent
																	public void tick(TickEvent.ServerTickEvent event) {
																		if (event.phase == TickEvent.Phase.END) {
																			this.ticks += 1;
																			if (this.ticks >= this.waitTicks)
																				run();
																		}
																	}

																	private void run() {
																		if (entity instanceof LivingEntity) {
																			Entity _ent = entity;
																			if (!_ent.world.isRemote()) {
																				SlashItem.shoot(_ent.world, (LivingEntity) entity, new Random(),
																						(float) 2,
																						(float) (((entity.getCapability(
																								ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																								null)
																								.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																								+ 5),
																						(int) 0.5);
																			}
																		}
																		if (entity instanceof LivingEntity) {
																			((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
																		}
																		new Object() {
																			private int ticks = 0;
																			private float waitTicks;
																			private IWorld world;
																			public void start(IWorld world, int waitTicks) {
																				this.waitTicks = waitTicks;
																				MinecraftForge.EVENT_BUS.register(this);
																				this.world = world;
																			}

																			@SubscribeEvent
																			public void tick(TickEvent.ServerTickEvent event) {
																				if (event.phase == TickEvent.Phase.END) {
																					this.ticks += 1;
																					if (this.ticks >= this.waitTicks)
																						run();
																				}
																			}

																			private void run() {
																				if (entity instanceof LivingEntity) {
																					Entity _ent = entity;
																					if (!_ent.world.isRemote()) {
																						SlashItem.shoot(_ent.world, (LivingEntity) entity,
																								new Random(), (float) 2,
																								(float) (((entity.getCapability(
																										ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																										null)
																										.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																										+ 5),
																								(int) 0.5);
																					}
																				}
																				if (entity instanceof LivingEntity) {
																					((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
																				}
																				new Object() {
																					private int ticks = 0;
																					private float waitTicks;
																					private IWorld world;
																					public void start(IWorld world, int waitTicks) {
																						this.waitTicks = waitTicks;
																						MinecraftForge.EVENT_BUS.register(this);
																						this.world = world;
																					}

																					@SubscribeEvent
																					public void tick(TickEvent.ServerTickEvent event) {
																						if (event.phase == TickEvent.Phase.END) {
																							this.ticks += 1;
																							if (this.ticks >= this.waitTicks)
																								run();
																						}
																					}

																					private void run() {
																						if (entity instanceof LivingEntity) {
																							Entity _ent = entity;
																							if (!_ent.world.isRemote()) {
																								SlashItem.shoot(_ent.world, (LivingEntity) entity,
																										new Random(), (float) 2,
																										(float) (((entity.getCapability(
																												ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																												null)
																												.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																												+ 5),
																										(int) 0.5);
																							}
																						}
																						if (entity instanceof LivingEntity) {
																							((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
																						}
																						new Object() {
																							private int ticks = 0;
																							private float waitTicks;
																							private IWorld world;
																							public void start(IWorld world, int waitTicks) {
																								this.waitTicks = waitTicks;
																								MinecraftForge.EVENT_BUS.register(this);
																								this.world = world;
																							}

																							@SubscribeEvent
																							public void tick(TickEvent.ServerTickEvent event) {
																								if (event.phase == TickEvent.Phase.END) {
																									this.ticks += 1;
																									if (this.ticks >= this.waitTicks)
																										run();
																								}
																							}

																							private void run() {
																								if (entity instanceof LivingEntity) {
																									Entity _ent = entity;
																									if (!_ent.world.isRemote()) {
																										SlashItem.shoot(_ent.world,
																												(LivingEntity) entity, new Random(),
																												(float) 2,
																												(float) (((entity.getCapability(
																														ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																														null)
																														.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																														+ 5),
																												(int) 0.5);
																									}
																								}
																								if (entity instanceof LivingEntity) {
																									((LivingEntity) entity).swing(Hand.MAIN_HAND,
																											true);
																								}
																								new Object() {
																									private int ticks = 0;
																									private float waitTicks;
																									private IWorld world;
																									public void start(IWorld world, int waitTicks) {
																										this.waitTicks = waitTicks;
																										MinecraftForge.EVENT_BUS.register(this);
																										this.world = world;
																									}

																									@SubscribeEvent
																									public void tick(
																											TickEvent.ServerTickEvent event) {
																										if (event.phase == TickEvent.Phase.END) {
																											this.ticks += 1;
																											if (this.ticks >= this.waitTicks)
																												run();
																										}
																									}

																									private void run() {
																										if (entity instanceof LivingEntity) {
																											Entity _ent = entity;
																											if (!_ent.world.isRemote()) {
																												SlashItem.shoot(_ent.world,
																														(LivingEntity) entity,
																														new Random(), (float) 2,
																														(float) (((entity
																																.getCapability(
																																		ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																		null)
																																.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																+ 5),
																														(int) 0.5);
																											}
																										}
																										if (entity instanceof LivingEntity) {
																											((LivingEntity) entity)
																													.swing(Hand.MAIN_HAND, true);
																										}
																										new Object() {
																											private int ticks = 0;
																											private float waitTicks;
																											private IWorld world;
																											public void start(IWorld world,
																													int waitTicks) {
																												this.waitTicks = waitTicks;
																												MinecraftForge.EVENT_BUS
																														.register(this);
																												this.world = world;
																											}

																											@SubscribeEvent
																											public void tick(
																													TickEvent.ServerTickEvent event) {
																												if (event.phase == TickEvent.Phase.END) {
																													this.ticks += 1;
																													if (this.ticks >= this.waitTicks)
																														run();
																												}
																											}

																											private void run() {
																												if (entity instanceof LivingEntity) {
																													Entity _ent = entity;
																													if (!_ent.world.isRemote()) {
																														SlashItem.shoot(_ent.world,
																																(LivingEntity) entity,
																																new Random(),
																																(float) 2,
																																(float) (((entity
																																		.getCapability(
																																				ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																				null)
																																		.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																		+ 5),
																																(int) 0.5);
																													}
																												}
																												if (entity instanceof LivingEntity) {
																													((LivingEntity) entity).swing(
																															Hand.MAIN_HAND, true);
																												}
																												new Object() {
																													private int ticks = 0;
																													private float waitTicks;
																													private IWorld world;
																													public void start(IWorld world,
																															int waitTicks) {
																														this.waitTicks = waitTicks;
																														MinecraftForge.EVENT_BUS
																																.register(this);
																														this.world = world;
																													}

																													@SubscribeEvent
																													public void tick(
																															TickEvent.ServerTickEvent event) {
																														if (event.phase == TickEvent.Phase.END) {
																															this.ticks += 1;
																															if (this.ticks >= this.waitTicks)
																																run();
																														}
																													}

																													private void run() {
																														if (entity instanceof LivingEntity) {
																															Entity _ent = entity;
																															if (!_ent.world
																																	.isRemote()) {
																																SlashItem.shoot(
																																		_ent.world,
																																		(LivingEntity) entity,
																																		new Random(),
																																		(float) 2,
																																		(float) (((entity
																																				.getCapability(
																																						ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																						null)
																																				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																				+ 5),
																																		(int) 0.5);
																															}
																														}
																														if (entity instanceof LivingEntity) {
																															((LivingEntity) entity)
																																	.swing(Hand.MAIN_HAND,
																																			true);
																														}
																														new Object() {
																															private int ticks = 0;
																															private float waitTicks;
																															private IWorld world;
																															public void start(
																																	IWorld world,
																																	int waitTicks) {
																																this.waitTicks = waitTicks;
																																MinecraftForge.EVENT_BUS
																																		.register(
																																				this);
																																this.world = world;
																															}

																															@SubscribeEvent
																															public void tick(
																																	TickEvent.ServerTickEvent event) {
																																if (event.phase == TickEvent.Phase.END) {
																																	this.ticks += 1;
																																	if (this.ticks >= this.waitTicks)
																																		run();
																																}
																															}

																															private void run() {
																																if (entity instanceof LivingEntity) {
																																	Entity _ent = entity;
																																	if (!_ent.world
																																			.isRemote()) {
																																		SlashItem
																																				.shoot(_ent.world,
																																						(LivingEntity) entity,
																																						new Random(),
																																						(float) 2,
																																						(float) (((entity
																																								.getCapability(
																																										ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																										null)
																																								.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																								+ 5),
																																						(int) 0.5);
																																	}
																																}
																																if (entity instanceof LivingEntity) {
																																	((LivingEntity) entity)
																																			.swing(Hand.MAIN_HAND,
																																					true);
																																}
																																new Object() {
																																	private int ticks = 0;
																																	private float waitTicks;
																																	private IWorld world;
																																	public void start(
																																			IWorld world,
																																			int waitTicks) {
																																		this.waitTicks = waitTicks;
																																		MinecraftForge.EVENT_BUS
																																				.register(
																																						this);
																																		this.world = world;
																																	}

																																	@SubscribeEvent
																																	public void tick(
																																			TickEvent.ServerTickEvent event) {
																																		if (event.phase == TickEvent.Phase.END) {
																																			this.ticks += 1;
																																			if (this.ticks >= this.waitTicks)
																																				run();
																																		}
																																	}

																																	private void run() {
																																		if (entity instanceof LivingEntity) {
																																			Entity _ent = entity;
																																			if (!_ent.world
																																					.isRemote()) {
																																				SlashItem
																																						.shoot(_ent.world,
																																								(LivingEntity) entity,
																																								new Random(),
																																								(float) 2,
																																								(float) (((entity
																																										.getCapability(
																																												ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																												null)
																																										.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																										+ 5),
																																								(int) 0.5);
																																			}
																																		}
																																		if (entity instanceof LivingEntity) {
																																			((LivingEntity) entity)
																																					.swing(Hand.MAIN_HAND,
																																							true);
																																		}
																																		new Object() {
																																			private int ticks = 0;
																																			private float waitTicks;
																																			private IWorld world;
																																			public void start(
																																					IWorld world,
																																					int waitTicks) {
																																				this.waitTicks = waitTicks;
																																				MinecraftForge.EVENT_BUS
																																						.register(
																																								this);
																																				this.world = world;
																																			}

																																			@SubscribeEvent
																																			public void tick(
																																					TickEvent.ServerTickEvent event) {
																																				if (event.phase == TickEvent.Phase.END) {
																																					this.ticks += 1;
																																					if (this.ticks >= this.waitTicks)
																																						run();
																																				}
																																			}

																																			private void run() {
																																				if (entity instanceof LivingEntity) {
																																					Entity _ent = entity;
																																					if (!_ent.world
																																							.isRemote()) {
																																						SlashItem
																																								.shoot(_ent.world,
																																										(LivingEntity) entity,
																																										new Random(),
																																										(float) 2,
																																										(float) (((entity
																																												.getCapability(
																																														ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY,
																																														null)
																																												.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength)
																																												+ 5),
																																										(int) 0.5);
																																					}
																																				}
																																				if (entity instanceof LivingEntity) {
																																					((LivingEntity) entity)
																																							.swing(Hand.MAIN_HAND,
																																									true);
																																				}
																																				MinecraftForge.EVENT_BUS
																																						.unregister(
																																								this);
																																			}
																																		}.start(world,
																																				(int) 0.1);
																																		MinecraftForge.EVENT_BUS
																																				.unregister(
																																						this);
																																	}
																																}.start(world,
																																		(int) 0.1);
																																MinecraftForge.EVENT_BUS
																																		.unregister(
																																				this);
																															}
																														}.start(world, (int) 0.1);
																														MinecraftForge.EVENT_BUS
																																.unregister(this);
																													}
																												}.start(world, (int) 0.1);
																												MinecraftForge.EVENT_BUS
																														.unregister(this);
																											}
																										}.start(world, (int) 0.1);
																										MinecraftForge.EVENT_BUS.unregister(this);
																									}
																								}.start(world, (int) 0.1);
																								MinecraftForge.EVENT_BUS.unregister(this);
																							}
																						}.start(world, (int) 0.1);
																						MinecraftForge.EVENT_BUS.unregister(this);
																					}
																				}.start(world, (int) 0.1);
																				MinecraftForge.EVENT_BUS.unregister(this);
																			}
																		}.start(world, (int) 0.1);
																		MinecraftForge.EVENT_BUS.unregister(this);
																	}
																}.start(world, (int) 0.1);
																MinecraftForge.EVENT_BUS.unregister(this);
															}
														}.start(world, (int) 0.1);
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, (int) 0.1);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, (int) 0.1);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, (int) 0.1);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, (int) 0.1);
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, (int) 0.1);
				if (entity instanceof LivingEntity) {
					Entity _ent = entity;
					if (!_ent.world.isRemote()) {
						SlashItem.shoot(_ent.world, (LivingEntity) entity, new Random(), (float) 2,
								(float) (((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).strength) + 5),
								(int) 0.5);
					}
				}
				{
					boolean _setval = (boolean) (false);
					entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.slashatkfire = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private IWorld world;
					public void start(IWorld world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						{
							boolean _setval = (boolean) (false);
							entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.cooldown2 = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, (int) 300);
			}
		}
	}
}
