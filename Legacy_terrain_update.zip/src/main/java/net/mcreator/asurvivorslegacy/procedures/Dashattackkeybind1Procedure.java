package net.mcreator.asurvivorslegacy.procedures;

import net.minecraft.entity.Entity;

import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModVariables;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.Map;

public class Dashattackkeybind1Procedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				ASurvivorsLegacyMod.LOGGER.warn("Failed to load dependency entity for procedure Dashattackkeybind1!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).cooldown1) == (false))) {
			if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).dashatk) == (true))) {
				if ((((entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ASurvivorsLegacyModVariables.PlayerVariables())).atk2) == 1)) {
					{
						boolean _setval = (boolean) (true);
						entity.getCapability(ASurvivorsLegacyModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.dashatkfire = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
				}
			}
		}
	}
}
