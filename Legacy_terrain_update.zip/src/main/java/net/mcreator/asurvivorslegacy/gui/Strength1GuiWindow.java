
package net.mcreator.asurvivorslegacy.gui;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import net.minecraft.client.Minecraft;

import net.mcreator.asurvivorslegacy.procedures.IfslashProcedure;
import net.mcreator.asurvivorslegacy.procedures.IflonswingProcedure;
import net.mcreator.asurvivorslegacy.procedures.IfdashProcedure;
import net.mcreator.asurvivorslegacy.procedures.If15Procedure;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.matrix.MatrixStack;

import com.google.common.collect.ImmutableMap;

@OnlyIn(Dist.CLIENT)
public class Strength1GuiWindow extends ContainerScreen<Strength1Gui.GuiContainerMod> {
	private World world;
	private int x, y, z;
	private PlayerEntity entity;
	private final static HashMap guistate = Strength1Gui.guistate;
	public Strength1GuiWindow(Strength1Gui.GuiContainerMod container, PlayerInventory inventory, ITextComponent text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.xSize = 404;
		this.ySize = 238;
	}
	private static final ResourceLocation texture = new ResourceLocation("a_survivors_legacy:textures/strength_1.png");
	@Override
	public void render(MatrixStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderHoveredTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void drawGuiContainerBackgroundLayer(MatrixStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.color4f(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		Minecraft.getInstance().getTextureManager().bindTexture(texture);
		int k = (this.width - this.xSize) / 2;
		int l = (this.height - this.ySize) / 2;
		this.blit(ms, k, l, 0, 0, this.xSize, this.ySize, this.xSize, this.ySize);
		Minecraft.getInstance().getTextureManager().bindTexture(new ResourceLocation("a_survivors_legacy:textures/nu.png"));
		this.blit(ms, this.guiLeft + 48, this.guiTop + 69, 0, 0, 60, 16, 60, 16);
		Minecraft.getInstance().getTextureManager().bindTexture(new ResourceLocation("a_survivors_legacy:textures/nu.png"));
		this.blit(ms, this.guiLeft + 171, this.guiTop + 70, 0, 0, 60, 16, 60, 16);
		Minecraft.getInstance().getTextureManager().bindTexture(new ResourceLocation("a_survivors_legacy:textures/nu.png"));
		this.blit(ms, this.guiLeft + 294, this.guiTop + 69, 0, 0, 60, 16, 60, 16);
		Minecraft.getInstance().getTextureManager().bindTexture(new ResourceLocation("a_survivors_legacy:textures/backk.png"));
		this.blit(ms, this.guiLeft + -38, this.guiTop + -45, 0, 0, 498, 325, 498, 325);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeScreen();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void tick() {
		super.tick();
	}

	@Override
	protected void drawGuiContainerForegroundLayer(MatrixStack ms, int mouseX, int mouseY) {
		this.font.drawString(ms, "Xp cost:5", 263, 16, -13369549);
		this.font.drawString(ms, "Xp cost: 15", 43, 52, -16711936);
		this.font.drawString(ms, "Xp cost: 15", 174, 53, -16711936);
		this.font.drawString(ms, "Xp cost: 15", 298, 53, -16711936);
		this.font.drawString(ms, "C to use ability", 29, 110, -65536);
		this.font.drawString(ms, "F to use ability", 164, 110, -65536);
		this.font.drawString(ms, "V to use ability", 286, 110, -65536);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardListener.enableRepeatEvents(false);
	}

	@Override
	public void init(Minecraft minecraft, int width, int height) {
		super.init(minecraft, width, height);
		minecraft.keyboardListener.enableRepeatEvents(true);
		this.addButton(new Button(this.guiLeft + 141, this.guiTop + 11, 120, 20, new StringTextComponent("strength multiplier"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(0, x, y, z));
				Strength1Gui.handleButtonAction(entity, 0, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 31, this.guiTop + 66, 70, 20, new StringTextComponent("air slash"), e -> {
			if (If15Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(1, x, y, z));
				Strength1Gui.handleButtonAction(entity, 1, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (If15Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 161, this.guiTop + 68, 80, 20, new StringTextComponent("dash attack"), e -> {
			if (If15Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(2, x, y, z));
				Strength1Gui.handleButtonAction(entity, 2, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (If15Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 287, this.guiTop + 68, 75, 20, new StringTextComponent("long swing"), e -> {
			if (If15Procedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(3, x, y, z));
				Strength1Gui.handleButtonAction(entity, 3, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (If15Procedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 44, this.guiTop + 90, 50, 20, new StringTextComponent("equip"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(4, x, y, z));
				Strength1Gui.handleButtonAction(entity, 4, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 177, this.guiTop + 90, 50, 20, new StringTextComponent("equip"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(5, x, y, z));
				Strength1Gui.handleButtonAction(entity, 5, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 302, this.guiTop + 90, 50, 20, new StringTextComponent("equip"), e -> {
			if (true) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(6, x, y, z));
				Strength1Gui.handleButtonAction(entity, 6, x, y, z);
			}
		}));
		this.addButton(new Button(this.guiLeft + 32, this.guiTop + 66, 70, 20, new StringTextComponent("air slash"), e -> {
			if (IfslashProcedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(7, x, y, z));
				Strength1Gui.handleButtonAction(entity, 7, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (IfslashProcedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 161, this.guiTop + 68, 80, 20, new StringTextComponent("dash attack"), e -> {
			if (IfdashProcedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(8, x, y, z));
				Strength1Gui.handleButtonAction(entity, 8, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (IfdashProcedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addButton(new Button(this.guiLeft + 287, this.guiTop + 68, 75, 20, new StringTextComponent("long swing"), e -> {
			if (IflonswingProcedure.executeProcedure(ImmutableMap.of("entity", entity))) {
				ASurvivorsLegacyMod.PACKET_HANDLER.sendToServer(new Strength1Gui.ButtonPressedMessage(9, x, y, z));
				Strength1Gui.handleButtonAction(entity, 9, x, y, z);
			}
		}) {
			@Override
			public void render(MatrixStack ms, int gx, int gy, float ticks) {
				if (IflonswingProcedure.executeProcedure(ImmutableMap.of("entity", entity)))
					super.render(ms, gx, gy, ticks);
			}
		});
	}
}
