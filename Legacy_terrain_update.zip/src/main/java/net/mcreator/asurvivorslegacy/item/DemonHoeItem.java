
package net.mcreator.asurvivorslegacy.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.HoeItem;

import net.mcreator.asurvivorslegacy.block.Demon_WoodPlanksBlock;
import net.mcreator.asurvivorslegacy.ASurvivorsLegacyModElements;

@ASurvivorsLegacyModElements.ModElement.Tag
public class DemonHoeItem extends ASurvivorsLegacyModElements.ModElement {
	@ObjectHolder("a_survivors_legacy:demon_hoe")
	public static final Item block = null;
	public DemonHoeItem(ASurvivorsLegacyModElements instance) {
		super(instance, 103);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new HoeItem(new IItemTier() {
			public int getMaxUses() {
				return 902;
			}

			public float getEfficiency() {
				return 10f;
			}

			public float getAttackDamage() {
				return 3f;
			}

			public int getHarvestLevel() {
				return 5;
			}

			public int getEnchantability() {
				return 35;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(Demon_WoodPlanksBlock.block));
			}
		}, 0, -3f, new Item.Properties().group(ItemGroup.TOOLS)) {
		}.setRegistryName("demon_hoe"));
	}
}
