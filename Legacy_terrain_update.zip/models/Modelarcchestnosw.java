// Made with Blockbench 3.9.2
// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
// Paste this class into your mod and generate all required imports

public static class Modelarcchestnosw extends EntityModel<Entity> {
	private final ModelRenderer Head;
	private final ModelRenderer Body;
	private final ModelRenderer Body_r1;
	private final ModelRenderer Body_r2;
	private final ModelRenderer Body_r3;
	private final ModelRenderer RightArm;
	private final ModelRenderer LeftArm;
	private final ModelRenderer RightLeg;
	private final ModelRenderer LeftLeg;

	public Modelarcchestnosw() {
		textureWidth = 64;
		textureHeight = 64;

		Head = new ModelRenderer(this);
		Head.setRotationPoint(0.0F, 0.0F, 0.0F);

		Body = new ModelRenderer(this);
		Body.setRotationPoint(0.0F, 0.0F, 0.0F);
		Body.setTextureOffset(0, 0).addBox(-4.0F, 0.0F, -3.0F, 8.0F, 8.0F, 6.0F, 0.0F, false);
		Body.setTextureOffset(0, 7).addBox(-4.0F, 8.0F, -3.0F, 8.0F, 6.0F, 6.0F, 0.0F, false);
		Body.setTextureOffset(24, 25).addBox(-4.0F, -0.5F, -3.75F, 1.0F, 1.0F, 7.0F, 0.0F, false);
		Body.setTextureOffset(15, 24).addBox(3.25F, 7.25F, -3.75F, 1.0F, 1.0F, 7.0F, 0.0F, false);
		Body.setTextureOffset(16, 32).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, 0.25F, false);

		Body_r1 = new ModelRenderer(this);
		Body_r1.setRotationPoint(-3.0F, 1.0F, 3.0F);
		Body.addChild(Body_r1);
		setRotationAngle(Body_r1, 0.5236F, -0.5236F, 0.0F);
		Body_r1.setTextureOffset(16, 32).addBox(-0.5F, -0.5F, 4.0F, 1.0F, 1.0F, 3.0F, 0.0F, false);
		Body_r1.setTextureOffset(28, 4).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F, 0.0F, false);

		Body_r2 = new ModelRenderer(this);
		Body_r2.setRotationPoint(3.0F, 1.0F, 3.0F);
		Body.addChild(Body_r2);
		setRotationAngle(Body_r2, 0.5236F, 0.5236F, 0.0F);
		Body_r2.setTextureOffset(21, 33).addBox(-0.5F, -0.5F, 4.0F, 1.0F, 1.0F, 3.0F, 0.0F, false);
		Body_r2.setTextureOffset(4, 30).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F, 0.0F, false);

		Body_r3 = new ModelRenderer(this);
		Body_r3.setRotationPoint(0.0F, 0.5F, 3.5F);
		Body.addChild(Body_r3);
		setRotationAngle(Body_r3, 0.0F, 0.0F, 0.7854F);
		Body_r3.setTextureOffset(22, 0).addBox(-3.0F, 1.75F, -1.0F, 11.0F, 1.0F, 1.0F, 0.0F, false);
		Body_r3.setTextureOffset(22, 2).addBox(-3.0F, 1.75F, -7.25F, 11.0F, 1.0F, 1.0F, 0.0F, false);

		RightArm = new ModelRenderer(this);
		RightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
		RightArm.setTextureOffset(22, 12).addBox(-4.0F, -2.0F, -3.0F, 5.0F, 6.0F, 6.0F, 0.0F, false);
		RightArm.setTextureOffset(40, 32).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, 0.25F, false);

		LeftArm = new ModelRenderer(this);
		LeftArm.setRotationPoint(6.0F, 2.0F, 0.0F);
		LeftArm.setTextureOffset(0, 18).addBox(-2.0F, -2.0F, -3.0F, 6.0F, 6.0F, 6.0F, 0.0F, false);
		LeftArm.setTextureOffset(48, 48).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 6.0F, 4.0F, 0.25F, false);

		RightLeg = new ModelRenderer(this);
		RightLeg.setRotationPoint(-1.9F, 12.0F, 0.0F);

		LeftLeg = new ModelRenderer(this);
		LeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);

	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red,
			float green, float blue, float alpha) {
		Head.render(matrixStack, buffer, packedLight, packedOverlay);
		Body.render(matrixStack, buffer, packedLight, packedOverlay);
		RightArm.render(matrixStack, buffer, packedLight, packedOverlay);
		LeftArm.render(matrixStack, buffer, packedLight, packedOverlay);
		RightLeg.render(matrixStack, buffer, packedLight, packedOverlay);
		LeftLeg.render(matrixStack, buffer, packedLight, packedOverlay);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, e);
		this.RightArm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float) Math.PI) * f1;
		this.LeftArm.rotateAngleX = MathHelper.cos(f * 0.6662F) * f1;
	}
}