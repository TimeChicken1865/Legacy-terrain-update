// Made with Blockbench 3.9.2
// Exported for Minecraft version 1.15 - 1.16 with MCP mappings
// Paste this class into your mod and generate all required imports

public static class Modelarcchest extends EntityModel<Entity> {
	private final ModelRenderer Head;
	private final ModelRenderer Body;
	private final ModelRenderer Body_r1;
	private final ModelRenderer Body_r2;
	private final ModelRenderer Body_r3;
	private final ModelRenderer sword;
	private final ModelRenderer cube_r1;
	private final ModelRenderer cube_r2;
	private final ModelRenderer cube_r3;
	private final ModelRenderer cube_r4;
	private final ModelRenderer cube_r5;
	private final ModelRenderer cube_r6;
	private final ModelRenderer cube_r7;
	private final ModelRenderer cube_r8;
	private final ModelRenderer cube_r9;
	private final ModelRenderer cube_r10;
	private final ModelRenderer tip;
	private final ModelRenderer cube_r11;
	private final ModelRenderer cube_r12;
	private final ModelRenderer RightArm;
	private final ModelRenderer LeftArm;
	private final ModelRenderer RightLeg;
	private final ModelRenderer LeftLeg;

	public Modelarcchest() {
		textureWidth = 64;
		textureHeight = 64;

		Head = new ModelRenderer(this);
		Head.setRotationPoint(0.0F, 0.0F, 0.0F);

		Body = new ModelRenderer(this);
		Body.setRotationPoint(0.0F, 0.0F, 0.0F);
		Body.setTextureOffset(0, 0).addBox(-4.0F, 0.0F, -3.0F, 8.0F, 8.0F, 6.0F, 0.0F, false);
		Body.setTextureOffset(0, 7).addBox(-4.0F, 8.0F, -3.0F, 8.0F, 6.0F, 6.0F, 0.0F, false);
		Body.setTextureOffset(24, 25).addBox(-4.0F, -0.5F, -3.75F, 1.0F, 1.0F, 7.0F, 0.0F, false);
		Body.setTextureOffset(15, 24).addBox(3.25F, 7.25F, -3.75F, 1.0F, 1.0F, 7.0F, 0.0F, false);
		Body.setTextureOffset(16, 32).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, 0.25F, false);

		Body_r1 = new ModelRenderer(this);
		Body_r1.setRotationPoint(-3.0F, 1.0F, 3.0F);
		Body.addChild(Body_r1);
		setRotationAngle(Body_r1, 0.5236F, -0.5236F, 0.0F);
		Body_r1.setTextureOffset(16, 32).addBox(-0.5F, -0.5F, 4.0F, 1.0F, 1.0F, 3.0F, 0.0F, false);
		Body_r1.setTextureOffset(28, 4).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F, 0.0F, false);

		Body_r2 = new ModelRenderer(this);
		Body_r2.setRotationPoint(3.0F, 1.0F, 3.0F);
		Body.addChild(Body_r2);
		setRotationAngle(Body_r2, 0.5236F, 0.5236F, 0.0F);
		Body_r2.setTextureOffset(21, 33).addBox(-0.5F, -0.5F, 4.0F, 1.0F, 1.0F, 3.0F, 0.0F, false);
		Body_r2.setTextureOffset(4, 30).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 4.0F, 0.0F, false);

		Body_r3 = new ModelRenderer(this);
		Body_r3.setRotationPoint(0.0F, 0.5F, 3.5F);
		Body.addChild(Body_r3);
		setRotationAngle(Body_r3, 0.0F, 0.0F, 0.7854F);
		Body_r3.setTextureOffset(22, 0).addBox(-3.0F, 1.75F, -1.0F, 11.0F, 1.0F, 1.0F, 0.0F, false);
		Body_r3.setTextureOffset(22, 2).addBox(-3.0F, 1.75F, -7.25F, 11.0F, 1.0F, 1.0F, 0.0F, false);

		sword = new ModelRenderer(this);
		sword.setRotationPoint(-4.0F, 0.0F, 9.0F);
		Body.addChild(sword);
		setRotationAngle(sword, 0.0F, 0.0F, 2.618F);
		sword.setTextureOffset(2, 30).addBox(-1.25F, -18.75F, -5.25F, 1.0F, 18.0F, 0.0F, 0.0F, false);
		sword.setTextureOffset(0, 30).addBox(0.25F, -18.75F, -5.25F, 1.0F, 18.0F, 0.0F, 0.0F, false);
		sword.setTextureOffset(0, 18).addBox(-0.5F, 2.0F, -5.5F, 1.0F, 4.0F, 1.0F, 0.0F, false);

		cube_r1 = new ModelRenderer(this);
		cube_r1.setRotationPoint(0.0F, 9.0F, -5.0F);
		sword.addChild(cube_r1);
		setRotationAngle(cube_r1, 0.0F, 0.0F, -0.7854F);
		cube_r1.setTextureOffset(0, 0).addBox(1.5F, -2.5F, -1.0F, 1.0F, 1.0F, 2.0F, 0.0F, false);

		cube_r2 = new ModelRenderer(this);
		cube_r2.setRotationPoint(-0.1585F, 0.7696F, -5.0F);
		sword.addChild(cube_r2);
		setRotationAngle(cube_r2, 0.0F, 0.0F, 0.7854F);
		cube_r2.setTextureOffset(24, 24).addBox(-0.5F, -3.0F, -0.75F, 1.0F, 6.0F, 1.0F, 0.0F, false);

		cube_r3 = new ModelRenderer(this);
		cube_r3.setRotationPoint(0.0F, 3.0F, -5.0F);
		sword.addChild(cube_r3);
		setRotationAngle(cube_r3, 0.0F, 0.0F, 0.3927F);
		cube_r3.setTextureOffset(0, 3).addBox(-1.5F, -4.0F, -0.5F, 2.0F, 0.0F, 1.0F, 0.0F, false);
		cube_r3.setTextureOffset(0, 0).addBox(0.5F, -5.25F, -0.25F, 0.0F, 1.0F, 0.0F, 0.0F, false);
		cube_r3.setTextureOffset(0, 0).addBox(-2.0F, 1.5F, -0.25F, 0.0F, 1.0F, 0.0F, 0.0F, false);

		cube_r4 = new ModelRenderer(this);
		cube_r4.setRotationPoint(0.0F, 3.0F, -5.0F);
		sword.addChild(cube_r4);
		setRotationAngle(cube_r4, 0.0F, 0.0F, -0.3927F);
		cube_r4.setTextureOffset(0, 4).addBox(-0.5F, -4.0F, -0.5F, 2.0F, 0.0F, 1.0F, 0.0F, false);
		cube_r4.setTextureOffset(0, 0).addBox(-1.0F, -5.25F, -0.25F, 0.0F, 1.0F, 0.0F, 0.0F, false);
		cube_r4.setTextureOffset(0, 0).addBox(1.75F, 1.5F, -0.25F, 0.0F, 1.0F, 0.0F, 0.0F, false);

		cube_r5 = new ModelRenderer(this);
		cube_r5.setRotationPoint(3.1803F, -2.7182F, -5.0F);
		sword.addChild(cube_r5);
		setRotationAngle(cube_r5, 0.0F, 0.0F, -0.3927F);
		cube_r5.setTextureOffset(0, 0).addBox(-0.5F, -1.75F, -0.25F, 0.0F, 1.0F, 0.0F, 0.0F, false);

		cube_r6 = new ModelRenderer(this);
		cube_r6.setRotationPoint(-3.1804F, -2.7182F, -5.0F);
		sword.addChild(cube_r6);
		setRotationAngle(cube_r6, 0.0F, 0.0F, 0.3927F);
		cube_r6.setTextureOffset(0, 0).addBox(0.0F, -1.75F, -0.25F, 0.0F, 1.0F, 0.0F, 0.0F, false);

		cube_r7 = new ModelRenderer(this);
		cube_r7.setRotationPoint(0.1585F, 0.7696F, -5.0F);
		sword.addChild(cube_r7);
		setRotationAngle(cube_r7, 0.0F, 0.0F, -0.7854F);
		cube_r7.setTextureOffset(29, 33).addBox(-0.5F, -3.0F, -0.75F, 1.0F, 6.0F, 1.0F, 0.0F, false);

		cube_r8 = new ModelRenderer(this);
		cube_r8.setRotationPoint(1.4979F, 4.0031F, -5.0F);
		sword.addChild(cube_r8);
		setRotationAngle(cube_r8, 0.0F, 0.0F, -0.7854F);
		cube_r8.setTextureOffset(0, 4).addBox(0.75F, -0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 0.0F, false);

		cube_r9 = new ModelRenderer(this);
		cube_r9.setRotationPoint(-1.4979F, 4.0031F, -5.0F);
		sword.addChild(cube_r9);
		setRotationAngle(cube_r9, 0.0F, 0.0F, 0.7854F);
		cube_r9.setTextureOffset(2, 4).addBox(-1.25F, -0.5F, -0.5F, 0.0F, 1.0F, 1.0F, 0.0F, false);

		cube_r10 = new ModelRenderer(this);
		cube_r10.setRotationPoint(0.0F, 1.5F, -5.0F);
		sword.addChild(cube_r10);
		setRotationAngle(cube_r10, 0.0F, 0.0F, 0.7854F);
		cube_r10.setTextureOffset(33, 24).addBox(-1.5F, -1.5F, -1.0F, 2.0F, 2.0F, 2.0F, 0.0F, false);

		tip = new ModelRenderer(this);
		tip.setRotationPoint(-8.75F, -14.0F, 0.0F);
		sword.addChild(tip);

		cube_r11 = new ModelRenderer(this);
		cube_r11.setRotationPoint(8.0F, -6.0F, -5.0F);
		tip.addChild(cube_r11);
		setRotationAngle(cube_r11, 0.0F, 0.0F, 0.3927F);
		cube_r11.setTextureOffset(0, 0).addBox(0.0F, -1.0F, -0.25F, 1.0F, 2.0F, 0.0F, 0.0F, false);
		cube_r11.setTextureOffset(0, 0).addBox(0.0F, -1.5F, -0.25F, 0.0F, 0.0F, 0.0F, 0.0F, false);
		cube_r11.setTextureOffset(0, 0).addBox(0.0F, -1.75F, -0.25F, 0.0F, 0.0F, 0.0F, 0.0F, false);

		cube_r12 = new ModelRenderer(this);
		cube_r12.setRotationPoint(9.5F, -6.0F, -5.0F);
		tip.addChild(cube_r12);
		setRotationAngle(cube_r12, 0.0F, 0.0F, -0.3927F);
		cube_r12.setTextureOffset(0, 0).addBox(-0.25F, -1.75F, -0.25F, 0.0F, 0.0F, 0.0F, 0.0F, false);
		cube_r12.setTextureOffset(0, 0).addBox(-0.5F, -1.5F, -0.25F, 0.0F, 0.0F, 0.0F, 0.0F, false);
		cube_r12.setTextureOffset(4, 0).addBox(-1.0F, -1.0F, -0.25F, 1.0F, 2.0F, 0.0F, 0.0F, false);

		RightArm = new ModelRenderer(this);
		RightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
		RightArm.setTextureOffset(22, 12).addBox(-4.0F, -2.0F, -3.0F, 5.0F, 6.0F, 6.0F, 0.0F, false);
		RightArm.setTextureOffset(40, 32).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F, 0.25F, false);

		LeftArm = new ModelRenderer(this);
		LeftArm.setRotationPoint(6.0F, 2.0F, 0.0F);
		LeftArm.setTextureOffset(0, 18).addBox(-2.0F, -2.0F, -3.0F, 6.0F, 6.0F, 6.0F, 0.0F, false);
		LeftArm.setTextureOffset(48, 48).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 6.0F, 4.0F, 0.25F, false);

		RightLeg = new ModelRenderer(this);
		RightLeg.setRotationPoint(-1.9F, 12.0F, 0.0F);

		LeftLeg = new ModelRenderer(this);
		LeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);

	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red,
			float green, float blue, float alpha) {
		Head.render(matrixStack, buffer, packedLight, packedOverlay);
		Body.render(matrixStack, buffer, packedLight, packedOverlay);
		RightArm.render(matrixStack, buffer, packedLight, packedOverlay);
		LeftArm.render(matrixStack, buffer, packedLight, packedOverlay);
		RightLeg.render(matrixStack, buffer, packedLight, packedOverlay);
		LeftLeg.render(matrixStack, buffer, packedLight, packedOverlay);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}

	public void setRotationAngles(float f, float f1, float f2, float f3, float f4, float f5, Entity e) {
		super.setRotationAngles(f, f1, f2, f3, f4, f5, e);
		this.RightArm.rotateAngleX = MathHelper.cos(f * 0.6662F + (float) Math.PI) * f1;
		this.LeftArm.rotateAngleX = MathHelper.cos(f * 0.6662F) * f1;
	}
}